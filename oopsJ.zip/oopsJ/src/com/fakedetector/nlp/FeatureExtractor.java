package com.fakedetector.nlp;

import com.fakedetector.model.LinguisticFeatures;

import java.util.*;

/**
 * Extracts quantitative stylometric and sentiment metrics from review text.
 */
public class FeatureExtractor {

    public LinguisticFeatures extract(String text) {
        if (text == null) text = "";

        int charCount = text.length();
        List<String> rawWords = Tokenizer.tokenizeWords(text);
        int wordCount = rawWords.size();

        if (wordCount == 0) {
            return new LinguisticFeatures(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        }

        Set<String> uniqueWords = new HashSet<>();
        int uppercaseWords = 0;
        int firstPerson = 0;
        int secondPerson = 0;
        int thirdPerson = 0;
        int positiveCount = 0;
        int negativeCount = 0;
        long totalCharLenInWords = 0;

        for (String w : rawWords) {
            String lower = w.toLowerCase();
            uniqueWords.add(lower);
            totalCharLenInWords += w.length();

            if (w.length() > 1 && w.equals(w.toUpperCase()) && Character.isLetter(w.charAt(0))) {
                uppercaseWords++;
            }

            if (SentimentLexicon.isFirstPerson(lower)) firstPerson++;
            if (SentimentLexicon.isSecondPerson(lower)) secondPerson++;
            if (SentimentLexicon.isThirdPerson(lower)) thirdPerson++;
            if (SentimentLexicon.isPositive(lower)) positiveCount++;
            if (SentimentLexicon.isNegative(lower)) negativeCount++;
        }

        double lexicalDiversity = (double) uniqueWords.size() / wordCount;
        double uppercaseRatio = (double) uppercaseWords / wordCount;
        double avgWordLength = (double) totalCharLenInWords / wordCount;

        // Punctuation counts
        int exclamationCount = countOccurrences(text, '!');
        int questionCount = countOccurrences(text, '?');

        // Extreme praise and negative phrase matching
        String lowerText = text.toLowerCase();
        int extremePraise = 0;
        for (String phrase : SentimentLexicon.getExtremePraisePhrases()) {
            if (lowerText.contains(phrase)) extremePraise++;
        }

        int extremeNegative = 0;
        for (String phrase : SentimentLexicon.getExtremeNegativePhrases()) {
            if (lowerText.contains(phrase)) extremeNegative++;
        }

        // Sentiment score: range -1.0 to +1.0
        int sentimentDiff = positiveCount - negativeCount;
        double sentimentScore = 0.0;
        if (positiveCount + negativeCount > 0) {
            sentimentScore = (double) sentimentDiff / (positiveCount + negativeCount);
        }

        // Emotional intensity: extreme polarity + excessive punctuation
        double emotionalIntensity = Math.min(1.0, 
            (Math.abs(sentimentScore) * 0.6) + 
            (Math.min(exclamationCount, 5) * 0.08) + 
            (Math.min(uppercaseWords, 5) * 0.06) +
            ((extremePraise + extremeNegative) * 0.15)
        );

        // Repetition score: checks for repeated words and repeated 2-grams
        double repetitionScore = calculateRepetitionScore(rawWords);

        // Simple Automated Readability Index approximation
        List<String> sentences = Tokenizer.tokenizeSentences(text);
        int sentenceCount = Math.max(1, sentences.size());
        double readability = 4.71 * ((double) totalCharLenInWords / wordCount) + 0.5 * ((double) wordCount / sentenceCount) - 21.43;
        readability = Math.max(1.0, Math.min(20.0, readability));

        return new LinguisticFeatures(
            charCount,
            wordCount,
            uniqueWords.size(),
            lexicalDiversity,
            uppercaseWords,
            uppercaseRatio,
            exclamationCount,
            questionCount,
            firstPerson,
            secondPerson,
            thirdPerson,
            extremePraise,
            extremeNegative,
            sentimentScore,
            emotionalIntensity,
            repetitionScore,
            avgWordLength,
            readability
        );
    }

    private int countOccurrences(String text, char target) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == target) count++;
        }
        return count;
    }

    private double calculateRepetitionScore(List<String> words) {
        if (words.size() < 4) return 0.0;
        int repeatedAdjacent = 0;
        for (int i = 0; i < words.size() - 1; i++) {
            if (words.get(i).equalsIgnoreCase(words.get(i + 1))) {
                repeatedAdjacent++;
            }
        }
        double ratio = (double) repeatedAdjacent / (words.size() - 1);
        return Math.min(1.0, ratio * 3.0);
    }
}
