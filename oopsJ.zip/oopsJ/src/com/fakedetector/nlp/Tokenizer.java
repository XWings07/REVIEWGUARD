package com.fakedetector.nlp;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Robust text tokenizer for extracting words, punctuation tokens, and n-grams.
 */
public class Tokenizer {

    private static final Pattern WORD_PATTERN = Pattern.compile("[a-zA-Z0-9]+(?:'[a-zA-Z]+)?");
    private static final Pattern SENTENCE_PATTERN = Pattern.compile("[^.!?]+[.!?]*");

    /**
     * Splits text into raw word tokens preserving original case.
     */
    public static List<String> tokenizeWords(String text) {
        List<String> tokens = new ArrayList<>();
        if (text == null || text.isEmpty()) return tokens;
        Matcher matcher = WORD_PATTERN.matcher(text);
        while (matcher.find()) {
            tokens.add(matcher.group());
        }
        return tokens;
    }

    /**
     * Splits text into lowercased normalized tokens.
     */
    public static List<String> tokenizeNormalized(String text) {
        List<String> raw = tokenizeWords(text);
        List<String> normalized = new ArrayList<>(raw.size());
        for (String t : raw) {
            normalized.add(t.toLowerCase());
        }
        return normalized;
    }

    /**
     * Splits text into sentences.
     */
    public static List<String> tokenizeSentences(String text) {
        List<String> sentences = new ArrayList<>();
        if (text == null || text.isEmpty()) return sentences;
        Matcher matcher = SENTENCE_PATTERN.matcher(text);
        while (matcher.find()) {
            String s = matcher.group().trim();
            if (!s.isEmpty()) {
                sentences.add(s);
            }
        }
        return sentences;
    }

    /**
     * Generates word bi-grams (2-grams).
     */
    public static List<String> generateBigrams(List<String> words) {
        List<String> bigrams = new ArrayList<>();
        for (int i = 0; i < words.size() - 1; i++) {
            bigrams.add(words.get(i).toLowerCase() + " " + words.get(i + 1).toLowerCase());
        }
        return bigrams;
    }
}
