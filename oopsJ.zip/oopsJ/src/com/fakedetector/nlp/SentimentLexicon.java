package com.fakedetector.nlp;

import java.util.*;

/**
 * Domain-specific lexicon for deceptive opinion spam, sentiment analysis, and credibility markers.
 */
public class SentimentLexicon {

    private static final Set<String> POSITIVE_WORDS = new HashSet<>(Arrays.asList(
        "good", "great", "excellent", "amazing", "wonderful", "fantastic", "awesome",
        "superb", "brilliant", "delighted", "love", "loved", "perfect", "pleased",
        "impressed", "solid", "durable", "reliable", "smooth", "comfortable", "helpful",
        "efficient", "worth", "sturdy", "quality", "valuable", "neat", "satisfied"
    ));

    private static final Set<String> NEGATIVE_WORDS = new HashSet<>(Arrays.asList(
        "bad", "terrible", "horrible", "awful", "poor", "disappointing", "broken",
        "defective", "useless", "cheap", "waste", "failed", "hate", "flimsy", "slow",
        "noisy", "uncomfortable", "damaged", "regret", "rude", "buggy", "inferior"
    ));

    // Exaggerated hype often associated with promotional fake reviews
    private static final Set<String> EXTREME_PRAISE_PHRASES = new HashSet<>(Arrays.asList(
        "best ever", "life changing", "miracle", "perfection", "unbelievable",
        "game changer", "holy grail", "buy it now", "buy buy buy", "must buy",
        "100% recommend", "blown away", "best in the world", "greatest ever",
        "flawless", "godsend", "unmatched quality", "pure magic", "five stars aren't enough"
    ));

    // Hyperbolic smear words often used in fake negative reviews (competitor sabotage)
    private static final Set<String> EXTREME_NEGATIVE_PHRASES = new HashSet<>(Arrays.asList(
        "absolute scam", "complete ripoff", "worst ever", "total garbage", "pure junk",
        "criminals", "stay away", "robbery", "do not buy", "worst company on earth",
        "toxic", "fraud", "scammers", "thieves", "zero stars"
    ));

    // Markers of sponsored or incentivized reviews
    private static final Set<String> INCENTIVE_MARKERS = new HashSet<>(Arrays.asList(
        "in exchange for", "honest review", "free product", "promotion", "received a discount",
        "sponsored", "review club", "sample provided", "complimentary"
    ));

    // Detailed, functional attributes typically found in genuine reviews
    private static final Set<String> GENUINE_ATTRIBUTES = new HashSet<>(Arrays.asList(
        "battery", "screen", "cable", "instructions", "support", "customer service",
        "size", "weight", "material", "button", "setup", "assembly", "delivery",
        "warranty", "packaging", "temperature", "measurement", "replacement", "sound",
        "volume", "connectivity", "bluetooth", "hinge", "texture", "fabric", "durability",
        "returned", "refunded", "months", "weeks", "daily use", "phone", "laptop",
        "camera", "food", "service", "staff", "price", "quality", "delivered", "package",
        "box", "arrived", "clean", "comfortable", "comfort", "display", "charge",
        "charger", "fast", "slow", "easy", "worth", "money", "bought", "using",
        "ordered", "order", "works", "worked", "working", "value", "photo", "photos",
        "bass", "speakers", "trackpad", "keyboard", "wifi", "room", "hotel", "restaurant",
        "taste", "delicious", "recommend", "recommended", "visit", "shipping"
    ));

    private static final Set<String> BALANCED_CONNECTORS = new HashSet<>(Arrays.asList(
        "however", "although", "though", "downside", "except", "drawback", "on the other hand",
        "pros and cons", "could be better", "bit small", "bit slow", "a bit", "slight"
    ));

    private static final Set<String> FIRST_PERSON_PRONOUNS = new HashSet<>(Arrays.asList(
        "i", "me", "my", "myself", "we", "us", "our", "ours"
    ));

    private static final Set<String> SECOND_PERSON_PRONOUNS = new HashSet<>(Arrays.asList(
        "you", "your", "yours", "yourself", "yourselves"
    ));

    private static final Set<String> THIRD_PERSON_PRONOUNS = new HashSet<>(Arrays.asList(
        "he", "him", "his", "she", "her", "hers", "it", "its", "they", "them", "their", "theirs"
    ));

    public static boolean isPositive(String word) {
        return POSITIVE_WORDS.contains(word.toLowerCase());
    }

    public static boolean isNegative(String word) {
        return NEGATIVE_WORDS.contains(word.toLowerCase());
    }

    public static boolean isFirstPerson(String word) {
        return FIRST_PERSON_PRONOUNS.contains(word.toLowerCase());
    }

    public static boolean isSecondPerson(String word) {
        return SECOND_PERSON_PRONOUNS.contains(word.toLowerCase());
    }

    public static boolean isThirdPerson(String word) {
        return THIRD_PERSON_PRONOUNS.contains(word.toLowerCase());
    }

    public static boolean isGenuineAttribute(String word) {
        return GENUINE_ATTRIBUTES.contains(word.toLowerCase());
    }

    public static Set<String> getExtremePraisePhrases() {
        return Collections.unmodifiableSet(EXTREME_PRAISE_PHRASES);
    }

    public static Set<String> getExtremeNegativePhrases() {
        return Collections.unmodifiableSet(EXTREME_NEGATIVE_PHRASES);
    }

    public static Set<String> getIncentiveMarkers() {
        return Collections.unmodifiableSet(INCENTIVE_MARKERS);
    }

    public static Set<String> getBalancedConnectors() {
        return Collections.unmodifiableSet(BALANCED_CONNECTORS);
    }
}
