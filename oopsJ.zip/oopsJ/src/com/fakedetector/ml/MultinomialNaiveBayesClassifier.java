package com.fakedetector.ml;

import com.fakedetector.model.TrainingSample;
import com.fakedetector.nlp.StopWordFilter;
import com.fakedetector.nlp.Tokenizer;

import java.util.*;

/**
 * Multinomial Naive Bayes text classifier with Laplace add-1 smoothing
 * and log-likelihood computation for numerical stability.
 */
public class MultinomialNaiveBayesClassifier implements Classifier {

    private final Map<String, Integer> fakeWordCounts = new HashMap<>();
    private final Map<String, Integer> genuineWordCounts = new HashMap<>();
    private final Set<String> vocabulary = new HashSet<>();

    private int totalFakeWords = 0;
    private int totalGenuineWords = 0;
    private int fakeDocsCount = 0;
    private int genuineDocsCount = 0;

    private double logPriorFake = 0.0;
    private double logPriorGenuine = 0.0;

    @Override
    public String getName() {
        return "Multinomial Naive Bayes (Laplace Smoothed)";
    }

    @Override
    public synchronized void train(List<TrainingSample> samples) {
        fakeWordCounts.clear();
        genuineWordCounts.clear();
        vocabulary.clear();
        totalFakeWords = 0;
        totalGenuineWords = 0;
        fakeDocsCount = 0;
        genuineDocsCount = 0;

        for (TrainingSample sample : samples) {
            boolean isFake = sample.isFake();
            if (isFake) {
                fakeDocsCount++;
            } else {
                genuineDocsCount++;
            }

            List<String> words = extractFeatures(sample.getText());
            for (String w : words) {
                vocabulary.add(w);
                if (isFake) {
                    fakeWordCounts.put(w, fakeWordCounts.getOrDefault(w, 0) + 1);
                    totalFakeWords++;
                } else {
                    genuineWordCounts.put(w, genuineWordCounts.getOrDefault(w, 0) + 1);
                    totalGenuineWords++;
                }
            }
        }

        int totalDocs = fakeDocsCount + genuineDocsCount;
        if (totalDocs > 0) {
            logPriorFake = Math.log((double) Math.max(1, fakeDocsCount) / totalDocs);
            logPriorGenuine = Math.log((double) Math.max(1, genuineDocsCount) / totalDocs);
        }
    }

    @Override
    public double predictFakeProbability(String text) {
        List<String> words = extractFeatures(text);
        if (words.isEmpty() || vocabulary.isEmpty()) {
            return 0.35; // neutral baseline
        }

        int vocabSize = vocabulary.size();
        double logPosteriorFake = logPriorFake;
        double logPosteriorGenuine = logPriorGenuine;
        int matchedWords = 0;

        for (String w : words) {
            // Out-of-vocabulary tokens provide zero statistical evidence and must be ignored
            // to prevent unequal class word totals from biasing probability calculations
            if (!vocabulary.contains(w)) {
                continue;
            }
            matchedWords++;

            // Laplace Add-1 Smoothing
            int countInFake = fakeWordCounts.getOrDefault(w, 0);
            double probWordFake = (double) (countInFake + 1) / (totalFakeWords + vocabSize);
            logPosteriorFake += Math.log(probWordFake);

            int countInGenuine = genuineWordCounts.getOrDefault(w, 0);
            double probWordGenuine = (double) (countInGenuine + 1) / (totalGenuineWords + vocabSize);
            logPosteriorGenuine += Math.log(probWordGenuine);
        }

        if (matchedWords == 0) {
            return 0.25; // Novel user review with no spam corpus tokens leans genuine
        }

        // Softmax / Log-sum-exp trick to convert log probabilities to normalized probability
        double maxLog = Math.max(logPosteriorFake, logPosteriorGenuine);
        double expFake = Math.exp(logPosteriorFake - maxLog);
        double expGenuine = Math.exp(logPosteriorGenuine - maxLog);

        double probFake = expFake / (expFake + expGenuine);
        return Math.min(0.999, Math.max(0.001, probFake));
    }

    private List<String> extractFeatures(String text) {
        List<String> rawTokens = Tokenizer.tokenizeNormalized(text);
        List<String> filtered = StopWordFilter.removeStopWords(rawTokens);

        // Include unigrams and bigrams
        List<String> bigrams = Tokenizer.generateBigrams(rawTokens);
        List<String> features = new ArrayList<>(filtered);
        features.addAll(bigrams);
        return features;
    }

    public Map<String, Integer> getFakeWordCounts() {
        return Collections.unmodifiableMap(fakeWordCounts);
    }

    public Map<String, Integer> getGenuineWordCounts() {
        return Collections.unmodifiableMap(genuineWordCounts);
    }
}
