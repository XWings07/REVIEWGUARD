package com.fakedetector.ml;

import com.fakedetector.model.LinguisticFeatures;
import com.fakedetector.nlp.SentimentLexicon;
import com.fakedetector.nlp.Tokenizer;

import java.util.ArrayList;
import java.util.List;

/**
 * Expert heuristic rule-based classifier based on NLP deception patterns and stylometry.
 */
public class RuleBasedEnsembleClassifier {

    public static class HeuristicResult {
        private final double deceptiveWeight; // 0.0 (genuine) to 1.0 (deceptive)
        private final List<String> flaggedIndicators;
        private final List<String> matchedDeceptivePatterns;
        private final List<String> positiveAttributes;

        public HeuristicResult(
                double deceptiveWeight,
                List<String> flaggedIndicators,
                List<String> matchedDeceptivePatterns,
                List<String> positiveAttributes) {
            this.deceptiveWeight = deceptiveWeight;
            this.flaggedIndicators = flaggedIndicators;
            this.matchedDeceptivePatterns = matchedDeceptivePatterns;
            this.positiveAttributes = positiveAttributes;
        }

        public double getDeceptiveWeight() { return deceptiveWeight; }
        public List<String> getFlaggedIndicators() { return flaggedIndicators; }
        public List<String> getMatchedDeceptivePatterns() { return matchedDeceptivePatterns; }
        public List<String> getPositiveAttributes() { return positiveAttributes; }
    }

    public HeuristicResult evaluate(String text, LinguisticFeatures features) {
        List<String> flags = new ArrayList<>();
        List<String> deceptivePatterns = new ArrayList<>();
        List<String> genuineAttributes = new ArrayList<>();

        double score = 0.20; // Default baseline: presumed authentic unless deception cues emerge
        String lower = text.toLowerCase();

        // Rule 1: Exaggerated Praise / Hyperbole (strong promotional spam cue)
        for (String phrase : SentimentLexicon.getExtremePraisePhrases()) {
            if (lower.contains(phrase)) {
                deceptivePatterns.add("Exaggerated praise phrase: '" + phrase + "'");
                score += 0.22;
            }
        }

        // Rule 2: Exaggerated Negative Smear Attack
        for (String phrase : SentimentLexicon.getExtremeNegativePhrases()) {
            if (lower.contains(phrase)) {
                deceptivePatterns.add("Extreme negative smear phrase: '" + phrase + "'");
                score += 0.24;
            }
        }

        // Rule 3: Promotional or Incentive Disclosures
        for (String marker : SentimentLexicon.getIncentiveMarkers()) {
            if (lower.contains(marker)) {
                deceptivePatterns.add("Sponsored/Incentive disclosure: '" + marker + "'");
                score += 0.28;
            }
        }

        // Rule 4: Excessive Exclamation Marks (4 or more denotes artificial shouting)
        if (features.getExclamationCount() >= 4) {
            flags.add("Abnormal exclamation count (" + features.getExclamationCount() + " marks) indicating artificial enthusiasm");
            score += 0.20;
        } else if (features.getExclamationCount() == 3) {
            score += 0.06;
        }

        // Rule 5: Heavy Uppercase / Screaming Words
        if (features.getUppercaseRatio() > 0.30 && features.getWordCount() > 5) {
            flags.add("High uppercase ratio (" + (Math.round(features.getUppercaseRatio() * 100)) + "%) typical of clickbait spam");
            score += 0.22;
        }

        // Rule 6: Pronoun Imbalance (Psychological deception cue from Ott et al.)
        // Fake reviews tend to exhibit heavily inflated 1st-person pronouns without concrete product nouns
        if (features.getWordCount() > 15) {
            double firstPersonRatio = (double) features.getFirstPersonPronounCount() / features.getWordCount();
            if (firstPersonRatio > 0.22) {
                flags.add("Disproportionate first-person narrative (" + features.getFirstPersonPronounCount() + " references), often used to manufacture artificial credibility");
                score += 0.12;
            }
        }

        // Rule 7: Very Short Generic Superlatives (Common low-effort bot review)
        if (features.getWordCount() <= 8 && features.getWordCount() >= 2) {
            if (features.getExtremePraiseCount() > 0 || (features.getSentimentScore() > 0.8 && features.getExclamationCount() >= 2)) {
                flags.add("Short, content-deficient generic praise review");
                score += 0.25;
            }
        }

        // Rule 8: Counterbalancing - Concrete Product Details & Specific Attributes
        List<String> tokens = Tokenizer.tokenizeNormalized(text);
        for (String t : tokens) {
            if (SentimentLexicon.isGenuineAttribute(t) && !genuineAttributes.contains(t)) {
                genuineAttributes.add(t);
                score -= 0.05; // Specific functional details reduce fake probability
            }
        }

        if (genuineAttributes.size() >= 2) {
            flags.add("Contains specific functional details (" + String.join(", ", genuineAttributes) + ")");
        }

        // Rule 9: Balanced Constructive Feedback (Hallmark of authentic purchaser critique)
        for (String connector : SentimentLexicon.getBalancedConnectors()) {
            if (lower.contains(connector)) {
                score -= 0.08;
                flags.add("Balanced constructive critique: '" + connector + "'");
                break;
            }
        }

        // Rule 10: Natural Review Length Bonus
        if (features.getWordCount() >= 10 && features.getWordCount() <= 100 && deceptivePatterns.isEmpty()) {
            score -= 0.05; // Healthy descriptive length without spam patterns
        }

        // Rule 11: Lexical Diversity Check (Bot repetition check)
        if (features.getWordCount() > 20 && features.getLexicalDiversity() < 0.40) {
            flags.add("Unusually low lexical diversity (" + Math.round(features.getLexicalDiversity() * 100) + "% unique words), indicating repetitive wording");
            score += 0.15;
        }

        // Clamp deceptive weight to [0.05, 0.95]
        double finalScore = Math.min(0.95, Math.max(0.05, score));

        return new HeuristicResult(finalScore, flags, deceptivePatterns, genuineAttributes);
    }
}
