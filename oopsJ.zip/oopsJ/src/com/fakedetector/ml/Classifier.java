package com.fakedetector.ml;

import com.fakedetector.model.TrainingSample;

import java.util.List;

/**
 * Common abstraction for review classification models following OOP polymorphism.
 */
public interface Classifier {

    /**
     * Trains the model using labeled samples.
     */
    void train(List<TrainingSample> samples);

    /**
     * Evaluates a review text and returns the predicted probability of it being fake (0.0 to 1.0).
     */
    double predictFakeProbability(String text);

    /**
     * Name identifier for the classifier.
     */
    String getName();
}
