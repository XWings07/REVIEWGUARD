package com.fakedetector.controller;

import com.fakedetector.model.AnalysisResult;
import com.fakedetector.model.AuditLog;
import com.fakedetector.model.User;
import com.fakedetector.service.AuthService;
import com.fakedetector.service.ReviewAnalysisService;
import com.fakedetector.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Controller providing the Owner/Admin with full access to audit logs,
 * registered users, login history, and all submitted reviews across all users.
 */
public class AdminHandler implements HttpHandler {

    private final ReviewAnalysisService analysisService;
    private final AuthService authService;

    public AdminHandler(ReviewAnalysisService analysisService) {
        this.analysisService = analysisService;
        this.authService = analysisService.getAuthService();
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        // Verify Owner/Admin Role
        String token = AuthHandler.extractToken(exchange);
        User currentUser = authService.getUserByToken(token);

        if (currentUser == null || !currentUser.isAdmin()) {
            sendError(exchange, 403, "Access Denied: Owner/Admin credentials required.");
            return;
        }

        String path = exchange.getRequestURI().getPath();

        try {
            if (path.endsWith("/logs")) {
                handleGetAuditLogs(exchange);
            } else if (path.endsWith("/users")) {
                handleGetUsers(exchange);
            } else if (path.endsWith("/all-reviews")) {
                handleGetAllReviews(exchange);
            } else {
                sendError(exchange, 404, "Unknown Admin Endpoint: " + path);
            }
        } catch (Exception e) {
            sendError(exchange, 500, "Error: " + e.getMessage());
        }
    }

    private void handleGetAuditLogs(HttpExchange exchange) throws IOException {
        List<AuditLog> logs = authService.getAuditLogRepository().getAllLogs();
        List<Map<String, Object>> list = new ArrayList<>();
        for (AuditLog l : logs) {
            list.add(l.toMap());
        }
        sendJson(exchange, 200, JsonUtil.toJson(list));
    }

    private void handleGetUsers(HttpExchange exchange) throws IOException {
        List<User> users = authService.getUserRepository().getAllUsers();
        List<Map<String, Object>> list = new ArrayList<>();
        for (User u : users) {
            list.add(u.toSafeMap());
        }
        sendJson(exchange, 200, JsonUtil.toJson(list));
    }

    private void handleGetAllReviews(HttpExchange exchange) throws IOException {
        List<AnalysisResult> allReviews = analysisService.getAllHistory();
        List<Map<String, Object>> list = new ArrayList<>();
        for (AnalysisResult ar : allReviews) {
            list.add(ar.toMap());
        }
        sendJson(exchange, 200, JsonUtil.toJson(list));
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(HttpExchange exchange, int status, String msg) throws IOException {
        Map<String, Object> map = new HashMap<>();
        map.put("error", msg);
        map.put("status", status);
        sendJson(exchange, status, JsonUtil.toJson(map));
    }
}
