package com.fakedetector.controller;

import com.fakedetector.model.AnalysisResult;
import com.fakedetector.model.User;
import com.fakedetector.service.ReviewAnalysisService;
import com.fakedetector.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Controller endpoint for retrieving scan history partitioned by user.
 */
public class HistoryHandler implements HttpHandler {

    private final ReviewAnalysisService service;

    public HistoryHandler(ReviewAnalysisService service) {
        this.service = service;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        String token = AuthHandler.extractToken(exchange);
        User currentUser = service.getAuthService().getUserByToken(token);

        if ("DELETE".equalsIgnoreCase(exchange.getRequestMethod())) {
            if (currentUser != null && currentUser.isAdmin()) {
                service.clearAllHistory();
            } else if (currentUser != null) {
                service.clearHistory(currentUser.getId());
            } else {
                service.clearHistory("guest");
            }
            Map<String, Object> resp = new HashMap<>();
            resp.put("message", "History cleared successfully.");
            sendJson(exchange, 200, JsonUtil.toJson(resp));
            return;
        }

        if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            List<AnalysisResult> history;
            if (currentUser != null) {
                if (currentUser.isAdmin()) {
                    history = service.getAllHistory();
                } else {
                    // Regular user sees their own tracked reviews
                    history = service.getHistory(currentUser.getId());
                }
            } else {
                // Guest sees guest scans or recent
                history = service.getHistory("guest");
            }

            List<Map<String, Object>> list = new ArrayList<>();
            for (AnalysisResult ar : history) {
                list.add(ar.toMap());
            }
            sendJson(exchange, 200, JsonUtil.toJson(list));
            return;
        }

        exchange.sendResponseHeaders(405, -1);
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
