package com.fakedetector.controller;

import com.fakedetector.model.AnalysisResult;
import com.fakedetector.model.User;
import com.fakedetector.service.ReviewAnalysisService;
import com.fakedetector.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Controller endpoint for processing individual review analyses with user session attribution.
 */
public class AnalyzeHandler implements HttpHandler {

    private final ReviewAnalysisService service;

    public AnalyzeHandler(ReviewAnalysisService service) {
        this.service = service;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        // Enable CORS
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendError(exchange, 405, "Method Not Allowed. Use POST.");
            return;
        }

        // Identify authenticated user or fallback to guest
        String token = AuthHandler.extractToken(exchange);
        User currentUser = service.getAuthService().getUserByToken(token);
        String userId = currentUser != null ? currentUser.getId() : "guest";
        String username = currentUser != null ? currentUser.getUsername() : "Anonymous / Guest";
        String ip = exchange.getRemoteAddress() != null ? exchange.getRemoteAddress().getAddress().getHostAddress() : "127.0.0.1";

        InputStream is = exchange.getRequestBody();
        String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);

        try {
            Map<String, Object> req = JsonUtil.parseObject(body);
            String text = (String) req.get("text");

            if (text == null || text.trim().isEmpty()) {
                sendError(exchange, 400, "Field 'text' is required.");
                return;
            }

            int rating = 0;
            if (req.get("rating") instanceof Number) {
                rating = ((Number) req.get("rating")).intValue();
            }

            AnalysisResult result = service.analyze(text, rating, userId, username, ip);
            String jsonResp = JsonUtil.toJson(result.toMap());

            byte[] bytes = jsonResp.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);

            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        } catch (Exception e) {
            sendError(exchange, 500, "Analysis failed: " + e.getMessage());
        }
    }

    private void sendError(HttpExchange exchange, int status, String message) throws IOException {
        Map<String, Object> err = new HashMap<>();
        err.put("error", message);
        err.put("status", status);
        String json = JsonUtil.toJson(err);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
