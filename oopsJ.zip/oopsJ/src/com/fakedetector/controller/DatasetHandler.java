package com.fakedetector.controller;

import com.fakedetector.model.ModelAccuracy;
import com.fakedetector.model.TrainingSample;
import com.fakedetector.service.ReviewAnalysisService;
import com.fakedetector.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Controller endpoint for inspecting dataset samples and retraining model dynamically.
 */
public class DatasetHandler implements HttpHandler {

    private final ReviewAnalysisService service;

    public DatasetHandler(ReviewAnalysisService service) {
        this.service = service;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            List<TrainingSample> samples = service.getDatasetSamples();
            List<Map<String, Object>> list = new ArrayList<>();
            for (TrainingSample s : samples) {
                Map<String, Object> map = new HashMap<>();
                map.put("text", s.getText());
                map.put("fake", s.isFake());
                map.put("category", s.getCategory());
                list.add(map);
            }
            sendJson(exchange, 200, JsonUtil.toJson(list));
            return;
        }

        if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            InputStream is = exchange.getRequestBody();
            String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            Map<String, Object> req = JsonUtil.parseObject(body);

            String text = (String) req.get("text");
            Boolean isFake = (Boolean) req.get("fake");
            String category = (String) req.getOrDefault("category", "General");

            if (text == null || text.trim().isEmpty() || isFake == null) {
                sendJson(exchange, 400, "{\"error\":\"Fields 'text' and 'fake' are required.\"}");
                return;
            }

            ModelAccuracy newAccuracy = service.retrainWithNewSample(text, isFake, category);
            Map<String, Object> resp = new HashMap<>();
            resp.put("message", "Sample added and model retrained successfully.");
            resp.put("updatedAccuracy", newAccuracy.toMap());
            sendJson(exchange, 200, JsonUtil.toJson(resp));
            return;
        }

        exchange.sendResponseHeaders(405, -1);
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
