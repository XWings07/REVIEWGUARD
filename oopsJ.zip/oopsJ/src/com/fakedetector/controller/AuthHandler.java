package com.fakedetector.controller;

import com.fakedetector.model.User;
import com.fakedetector.service.AuthService;
import com.fakedetector.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller handling user registration, authentication, sessions, and profile checks.
 */
public class AuthHandler implements HttpHandler {

    private final AuthService authService;

    public AuthHandler(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        String path = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod();
        String ip = exchange.getRemoteAddress() != null ? exchange.getRemoteAddress().getAddress().getHostAddress() : "127.0.0.1";

        try {
            if (path.endsWith("/register") && "POST".equalsIgnoreCase(method)) {
                handleRegister(exchange, ip);
            } else if (path.endsWith("/login") && "POST".equalsIgnoreCase(method)) {
                handleLogin(exchange, ip);
            } else if (path.endsWith("/me") && "GET".equalsIgnoreCase(method)) {
                handleMe(exchange);
            } else if (path.endsWith("/logout") && "POST".equalsIgnoreCase(method)) {
                handleLogout(exchange, ip);
            } else {
                sendError(exchange, 404, "Unknown Auth Endpoint: " + path);
            }
        } catch (IllegalArgumentException e) {
            sendError(exchange, 400, e.getMessage());
        } catch (Exception e) {
            sendError(exchange, 500, "Internal Server Error: " + e.getMessage());
        }
    }

    private void handleRegister(HttpExchange exchange, String ip) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, Object> req = JsonUtil.parseObject(body);

        String username = (String) req.get("username");
        String email = (String) req.get("email");
        String password = (String) req.get("password");

        Map<String, Object> resp = authService.register(username, email, password, ip);
        sendJson(exchange, 201, JsonUtil.toJson(resp));
    }

    private void handleLogin(HttpExchange exchange, String ip) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, Object> req = JsonUtil.parseObject(body);

        String username = (String) req.get("username");
        String password = (String) req.get("password");

        Map<String, Object> resp = authService.login(username, password, ip);
        sendJson(exchange, 200, JsonUtil.toJson(resp));
    }

    private void handleMe(HttpExchange exchange) throws IOException {
        String token = extractToken(exchange);
        User user = authService.getUserByToken(token);
        if (user == null) {
            sendError(exchange, 401, "Unauthorized: Please log in first.");
            return;
        }
        sendJson(exchange, 200, JsonUtil.toJson(user.toSafeMap()));
    }

    private void handleLogout(HttpExchange exchange, String ip) throws IOException {
        String token = extractToken(exchange);
        authService.logout(token, ip);
        Map<String, Object> resp = new HashMap<>();
        resp.put("message", "Logged out successfully.");
        sendJson(exchange, 200, JsonUtil.toJson(resp));
    }

    public static String extractToken(HttpExchange exchange) {
        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7).trim();
        }
        // Fallback to query param ?token=
        String query = exchange.getRequestURI().getQuery();
        if (query != null && query.contains("token=")) {
            for (String param : query.split("&")) {
                if (param.startsWith("token=")) {
                    return param.substring(6).trim();
                }
            }
        }
        return null;
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(HttpExchange exchange, int status, String msg) throws IOException {
        Map<String, Object> map = new HashMap<>();
        map.put("error", msg);
        map.put("status", status);
        sendJson(exchange, status, JsonUtil.toJson(map));
    }
}
