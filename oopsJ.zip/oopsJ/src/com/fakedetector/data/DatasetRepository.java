package com.fakedetector.data;

import com.fakedetector.model.TrainingSample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Preloaded training and benchmark dataset with verified deceptive and authentic reviews.
 */
public class DatasetRepository {

    private final List<TrainingSample> samples = new ArrayList<>();

    public DatasetRepository() {
        loadDefaultDataset();
    }

    private void loadDefaultDataset() {
        // --- DECEPTIVE / FAKE SAMPLES ---
        samples.add(new TrainingSample(
            "BEST PRODUCT EVER A+++ BUY BUY BUY!!! CHANGED MY LIFE!! Five stars aren't enough!",
            true, "E-Commerce"
        ));
        samples.add(new TrainingSample(
            "Unbelievable miracle product! I received a free product in exchange for this honest review. 100% recommend to everyone!",
            true, "Health"
        ));
        samples.add(new TrainingSample(
            "DO NOT BUY TOTAL SCAM! Worst company on earth, criminals and thieves! Stay away!",
            true, "Electronics"
        ));
        samples.add(new TrainingSample(
            "Holy grail product! Pure magic! I bought this and immediately my skin was flawless within 5 minutes!",
            true, "Beauty"
        ));
        samples.add(new TrainingSample(
            "AMAZING EXCELLENT WONDERFUL! Works great, loved it so much, everyone must buy this immediately!",
            true, "General"
        ));
        samples.add(new TrainingSample(
            "I received this item with a promotional discount code. As an honest reviewer, this is the greatest creation in history.",
            true, "Promotional"
        ));
        samples.add(new TrainingSample(
            "Great product loved it five stars!! Best ever!",
            true, "E-Commerce"
        ));
        samples.add(new TrainingSample(
            "Complete garbage pure junk broke immediately! Robbery! Zero stars if I could!",
            true, "Electronics"
        ));
        samples.add(new TrainingSample(
            "I never write reviews but WOW. Game changer! Godsend! Blown away by the unmatched perfection!",
            true, "General"
        ));
        samples.add(new TrainingSample(
            "BUY IT NOW! TRUST ME YOU WILL NOT REGRET IT!! 1000% SATISFACTION GUARANTEED!!",
            true, "E-Commerce"
        ));
        samples.add(new TrainingSample(
            "Sample provided by seller for testing purposes. Simply flawless perfection in every way.",
            true, "Promotional"
        ));
        samples.add(new TrainingSample(
            "Life changing experience! The greatest hotel in the entire world! Pure magic!",
            true, "Hotel"
        ));

        // --- AUTHENTIC / GENUINE SAMPLES ---
        samples.add(new TrainingSample(
            "I've been using this keyboard for three weeks. The mechanical switches have good tactile feedback, but the spacebar has a slight rattle. Battery life lasted about 35 hours on Bluetooth before needing a recharge.",
            false, "Electronics"
        ));
        samples.add(new TrainingSample(
            "Solid winter coat. The stitching around the shoulders feels durable and the zipper doesn't snag. However, the sizing runs a bit small, so consider ordering one size up if you plan to wear thick sweaters.",
            false, "Apparel"
        ));
        samples.add(new TrainingSample(
            "The screen resolution is sharp and colors look accurate out of the box. Setup took about 15 minutes. The only downside is the built-in speakers which lack bass, so I paired it with external monitors.",
            false, "Electronics"
        ));
        samples.add(new TrainingSample(
            "Arrived in sturdy packaging with all cables and the user manual included. Customer support replaced a missing screw within 48 hours. Good value for the price.",
            false, "Home"
        ));
        samples.add(new TrainingSample(
            "Decent stay overall. The room was clean and air conditioning worked quietly. The elevator was under maintenance during our second day, so we had to use the stairs.",
            false, "Hotel"
        ));
        samples.add(new TrainingSample(
            "Food arrived hot within 35 minutes of ordering. The crust was crispy and sauce was flavorful, though the pepperoni had a bit too much grease. Would order again for weekend takeout.",
            false, "Restaurant"
        ));
        samples.add(new TrainingSample(
            "After 2 months of daily use, the blender handles frozen berries and ice without overheating. The plastic pitcher has held up in the dishwasher with no clouding.",
            false, "Kitchen"
        ));
        samples.add(new TrainingSample(
            "The noise cancellation works well for office chatter and bus hum, but doesn't block high-frequency sounds completely. The ear cups can get warm after about two hours.",
            false, "Audio"
        ));
        samples.add(new TrainingSample(
            "Purchased for my home office. Assembly required two people and a screwdriver. The wood veneer looks clean, though the drawer slides could be smoother.",
            false, "Furniture"
        ));
        samples.add(new TrainingSample(
            "Battery drained faster than advertised when running video editing apps (around 4 hours instead of 8). Otherwise, fast thermal management and quiet fans.",
            false, "Computers"
        ));
        samples.add(new TrainingSample(
            "Customer service handled my return efficiently when the first unit arrived with a damaged corner. The replacement unit works without issues.",
            false, "Service"
        ));
        samples.add(new TrainingSample(
            "Fit is true to measurement table. Fabric is lightweight polyester, suitable for summer running. Pockets are deep enough to hold a 6.5 inch phone securely.",
            false, "Sports"
        ));
        samples.add(new TrainingSample(
            "I bought this phone last week. Battery lasts all day with heavy use and the camera quality is great for the price. Fast charging works well.",
            false, "Electronics"
        ));
        samples.add(new TrainingSample(
            "Good product. Works well and packaging was nice. Delivered on time without any damage.",
            false, "E-Commerce"
        ));
        samples.add(new TrainingSample(
            "The food was delicious and service was fast. Friendly staff and clean dining area. Would visit again for weekend dinner.",
            false, "Restaurant"
        ));
        samples.add(new TrainingSample(
            "Great laptop for college students. It handles daily coding, video calls, and web browsing smoothly without lag.",
            false, "Computers"
        ));
        samples.add(new TrainingSample(
            "Ordered this jacket online. Warm and comfortable fabric. The zipper feels sturdy and it fits exactly as expected.",
            false, "Apparel"
        ));
        samples.add(new TrainingSample(
            "Good value for money. Sound quality is clear and pairing with my phone via bluetooth was simple and fast.",
            false, "Audio"
        ));
        samples.add(new TrainingSample(
            "Average quality. Works fine for basic office tasks, but the plastic casing feels a little cheap.",
            false, "Electronics"
        ));
    }

    public synchronized List<TrainingSample> getAllSamples() {
        return Collections.unmodifiableList(new ArrayList<>(samples));
    }

    public synchronized void addSample(TrainingSample sample) {
        if (sample != null) {
            samples.add(sample);
        }
    }

    public synchronized int getCount() {
        return samples.size();
    }
}
