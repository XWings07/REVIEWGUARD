package com.fakedetector.data;

import com.fakedetector.model.AuditLog;
import com.fakedetector.util.JsonUtil;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Thread-safe audit log repository capturing all user actions and review submissions.
 * Persists log records to data/audit_logs.json so the owner can track who logged in and what was analyzed.
 */
public class AuditLogRepository {

    private static final String LOG_PATH = "data/audit_logs.json";
    private final List<AuditLog> logs = new CopyOnWriteArrayList<>();

    public AuditLogRepository() {
        loadFromDisk();
    }

    public synchronized void log(String userId, String username, String action, String details, String ipAddress) {
        AuditLog entry = new AuditLog(userId, username, action, details, ipAddress);
        logs.add(0, entry); // Newest first

        // Keep maximum 500 records in memory
        if (logs.size() > 500) {
            logs.remove(logs.size() - 1);
        }

        flushToDisk();
    }

    public List<AuditLog> getAllLogs() {
        return Collections.unmodifiableList(logs);
    }

    public List<AuditLog> getLogsByUser(String userId) {
        List<AuditLog> filtered = new ArrayList<>();
        for (AuditLog l : logs) {
            if (l.getUserId().equalsIgnoreCase(userId)) {
                filtered.add(l);
            }
        }
        return filtered;
    }

    private synchronized void flushToDisk() {
        try {
            Path path = Paths.get(LOG_PATH);
            Files.createDirectories(path.getParent());

            List<Map<String, Object>> list = new ArrayList<>();
            for (AuditLog l : logs) {
                list.add(l.toMap());
            }

            String json = JsonUtil.toJson(list);
            Files.write(path, json.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Warning: Failed to flush audit logs to disk: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private synchronized void loadFromDisk() {
        File file = new File(LOG_PATH);
        if (!file.exists()) return;

        try {
            String json = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            Object parsed = JsonUtil.parse(json);
            if (parsed instanceof List<?>) {
                List<?> list = (List<?>) parsed;
                for (Object item : list) {
                    if (item instanceof Map<?, ?>) {
                        Map<String, Object> map = (Map<String, Object>) item;
                        String id = (String) map.get("id");
                        long timestamp = map.get("timestamp") instanceof Number ? ((Number) map.get("timestamp")).longValue() : System.currentTimeMillis();
                        String userId = (String) map.get("userId");
                        String username = (String) map.get("username");
                        String action = (String) map.get("action");
                        String details = (String) map.get("details");
                        String ipAddress = (String) map.get("ipAddress");

                        if (action != null) {
                            logs.add(new AuditLog(id, timestamp, userId, username, action, details, ipAddress));
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Warning: Could not parse audit_logs.json, starting fresh: " + e.getMessage());
        }
    }
}
