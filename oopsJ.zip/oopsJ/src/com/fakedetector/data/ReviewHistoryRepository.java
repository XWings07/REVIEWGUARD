package com.fakedetector.data;

import com.fakedetector.model.AnalysisResult;
import com.fakedetector.util.JsonUtil;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Thread-safe repository for review analysis history with user segregation and file persistence.
 */
public class ReviewHistoryRepository {

    private static final String HISTORY_PATH = "data/review_history.json";
    private final List<AnalysisResult> history = new CopyOnWriteArrayList<>();

    public void add(AnalysisResult result) {
        if (result != null) {
            // Keep latest first
            history.add(0, result);
            flushToDisk();
        }
    }

    public List<AnalysisResult> getAll() {
        return Collections.unmodifiableList(history);
    }

    public List<AnalysisResult> getByUserId(String userId) {
        if (userId == null || userId.isEmpty()) {
            return Collections.unmodifiableList(history);
        }
        List<AnalysisResult> userList = new ArrayList<>();
        for (AnalysisResult r : history) {
            if (userId.equalsIgnoreCase(r.getUserId())) {
                userList.add(r);
            }
        }
        return userList;
    }

    public void clear() {
        history.clear();
        flushToDisk();
    }

    public void clearByUser(String userId) {
        if (userId == null || userId.isEmpty()) return;
        history.removeIf(r -> userId.equalsIgnoreCase(r.getUserId()));
        flushToDisk();
    }

    public int size() {
        return history.size();
    }

    public Map<String, Object> getAggregateStats(String userId) {
        List<AnalysisResult> target = (userId == null || userId.isEmpty()) ? history : getByUserId(userId);
        int total = target.size();
        int fakeCount = 0;
        int genuineCount = 0;
        int suspiciousCount = 0;
        double sumConfidence = 0.0;
        Map<String, Integer> patternFrequency = new HashMap<>();

        for (AnalysisResult r : target) {
            if ("FAKE".equalsIgnoreCase(r.getVerdict())) fakeCount++;
            else if ("GENUINE".equalsIgnoreCase(r.getVerdict())) genuineCount++;
            else suspiciousCount++;

            sumConfidence += r.getConfidenceScore();

            for (String p : r.getMatchedDeceptivePatterns()) {
                patternFrequency.put(p, patternFrequency.getOrDefault(p, 0) + 1);
            }
        }

        double avgConfidence = total > 0 ? (sumConfidence / total) : 0.0;

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalScans", total);
        stats.put("fakeCount", fakeCount);
        stats.put("genuineCount", genuineCount);
        stats.put("suspiciousCount", suspiciousCount);
        stats.put("fakePercentage", total > 0 ? Math.round(((double) fakeCount / total) * 1000.0) / 10.0 : 0.0);
        stats.put("genuinePercentage", total > 0 ? Math.round(((double) genuineCount / total) * 1000.0) / 10.0 : 0.0);
        stats.put("averageConfidence", Math.round(avgConfidence * 10.0) / 10.0);
        stats.put("topPatterns", patternFrequency);
        return stats;
    }

    private synchronized void flushToDisk() {
        try {
            Path path = Paths.get(HISTORY_PATH);
            Files.createDirectories(path.getParent());

            List<Map<String, Object>> list = new ArrayList<>();
            for (AnalysisResult ar : history) {
                list.add(ar.toMap());
            }

            String json = JsonUtil.toJson(list);
            Files.write(path, json.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Warning: Failed to flush review history to disk: " + e.getMessage());
        }
    }
}
