package com.fakedetector.data;

import com.fakedetector.model.User;
import com.fakedetector.util.JsonUtil;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe user repository with file persistence to data/users.json.
 * Pre-seeds default Owner (Admin) and sample user accounts.
 */
public class UserRepository {

    private static final String STORAGE_PATH = "data/users.json";
    private final Map<String, User> usersById = new ConcurrentHashMap<>();
    private final Map<String, User> usersByUsername = new ConcurrentHashMap<>();

    public UserRepository() {
        loadFromDisk();
        seedDefaultAccountsIfEmpty();
    }

    private synchronized void seedDefaultAccountsIfEmpty() {
        if (usersByUsername.isEmpty()) {
            // Default Owner Account
            User admin = new User("admin", "admin@veritas.ai", "admin123", "ADMIN");
            // Default Regular User Account
            User regular = new User("reviewer", "reviewer@demo.com", "user123", "USER");

            saveInternal(admin);
            saveInternal(regular);
            flushToDisk();
        }
    }

    private void saveInternal(User user) {
        usersById.put(user.getId(), user);
        usersByUsername.put(user.getUsername().toLowerCase(), user);
    }

    public synchronized User register(String username, String email, String password, String role) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty.");
        }
        if (password == null || password.trim().length() < 4) {
            throw new IllegalArgumentException("Password must be at least 4 characters long.");
        }

        String normalizedUser = username.trim().toLowerCase();
        if (usersByUsername.containsKey(normalizedUser)) {
            throw new IllegalArgumentException("Username '" + username + "' is already taken.");
        }

        User newUser = new User(username.trim(), email != null ? email.trim() : "", password, role);
        saveInternal(newUser);
        flushToDisk();
        return newUser;
    }

    public User authenticate(String username, String password) {
        if (username == null || password == null) return null;
        User user = usersByUsername.get(username.trim().toLowerCase());
        if (user != null && user.getPassword().equals(password)) {
            user.setLastLoginAt(System.currentTimeMillis());
            flushToDisk();
            return user;
        }
        return null;
    }

    public User findById(String id) {
        return usersById.get(id);
    }

    public User findByUsername(String username) {
        if (username == null) return null;
        return usersByUsername.get(username.trim().toLowerCase());
    }

    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>(usersById.values());
        list.sort((a, b) -> Long.compare(b.getCreatedAt(), a.getCreatedAt()));
        return list;
    }

    private synchronized void flushToDisk() {
        try {
            Path path = Paths.get(STORAGE_PATH);
            Files.createDirectories(path.getParent());

            List<Map<String, Object>> list = new ArrayList<>();
            for (User u : usersById.values()) {
                list.add(u.toStorageMap());
            }

            String json = JsonUtil.toJson(list);
            Files.write(path, json.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Warning: Failed to persist users to disk: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private synchronized void loadFromDisk() {
        File file = new File(STORAGE_PATH);
        if (!file.exists()) return;

        try {
            String json = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            Object parsed = JsonUtil.parse(json);
            if (parsed instanceof List<?>) {
                List<?> list = (List<?>) parsed;
                for (Object item : list) {
                    if (item instanceof Map<?, ?>) {
                        Map<String, Object> map = (Map<String, Object>) item;
                        String id = (String) map.get("id");
                        String username = (String) map.get("username");
                        String email = (String) map.get("email");
                        String password = (String) map.get("password");
                        String role = (String) map.get("role");
                        long createdAt = map.get("createdAt") instanceof Number ? ((Number) map.get("createdAt")).longValue() : System.currentTimeMillis();
                        long lastLoginAt = map.get("lastLoginAt") instanceof Number ? ((Number) map.get("lastLoginAt")).longValue() : System.currentTimeMillis();

                        if (id != null && username != null && password != null) {
                            User u = new User(id, username, email, password, role, createdAt, lastLoginAt);
                            saveInternal(u);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Warning: Could not parse users.json, initializing fresh: " + e.getMessage());
        }
    }
}
