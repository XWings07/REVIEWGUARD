package com.fakedetector;

import com.fakedetector.controller.*;
import com.fakedetector.service.ReviewAnalysisService;
import com.sun.net.httpserver.HttpServer;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

/**
 * Main application entry point for the Fake Review Detector server and dashboard.
 */
public class HttpServerApp {

    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) {
        int port = DEFAULT_PORT;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException ignored) {}
        }

        // Determine web assets folder
        String webPath = "web";
        File webDir = new File(webPath);
        if (!webDir.exists()) {
            // Check parent or relative to oopsJ directory
            webDir = new File("../web");
            if (webDir.exists()) {
                webPath = "../web";
            }
        }

        try {
            System.out.println("==========================================================");
            System.out.println("       Fake Review Detection System - Backend Server       ");
            System.out.println("==========================================================");
            System.out.println(" > Loading NLP Lexicons and Training Dataset...");

            ReviewAnalysisService service = new ReviewAnalysisService();

            System.out.println(" > Naive Bayes Model Trained! Accuracy: " 
                + Math.round(service.getModelAccuracy().getAccuracy() * 1000.0) / 10.0 + "%");
            System.out.println(" > Starting HTTP Server on port " + port + "...");

            HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

            // API Endpoints
            server.createContext("/api/analyze", new AnalyzeHandler(service));
            server.createContext("/api/history", new HistoryHandler(service));
            server.createContext("/api/stats", new StatsHandler(service));
            server.createContext("/api/dataset", new DatasetHandler(service));
            server.createContext("/api/auth", new AuthHandler(service.getAuthService()));
            server.createContext("/api/admin", new AdminHandler(service));

            // Static Web Assets
            server.createContext("/", new StaticFileHandler(webPath));

            server.setExecutor(Executors.newFixedThreadPool(10));
            server.start();

            System.out.println("==========================================================");
            System.out.println(" Server Started Successfully!                             ");
            System.out.println("  * Main Application:  http://localhost:" + port + "            ");
            System.out.println("  * Admin Portal:      http://localhost:" + port + "/admin      ");
            System.out.println("  * Default Admin:     admin / admin123                   ");
            System.out.println("  * Member Login:      reviewer / user123                 ");
            System.out.println("==========================================================");
            System.out.println("   Press Ctrl+C to stop the server anytime.               ");

        } catch (IOException e) {
            System.err.println("Fatal Error starting HTTP Server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
