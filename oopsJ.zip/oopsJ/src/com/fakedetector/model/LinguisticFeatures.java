package com.fakedetector.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Encapsulates linguistic, stylistic, and statistical features extracted from a review.
 * Grounded in research on deceptive opinion spam (e.g., Ott et al., Cornell NLP).
 */
public class LinguisticFeatures {
    private final int characterCount;
    private final int wordCount;
    private final int uniqueWordCount;
    private final double lexicalDiversity; // Type-Token Ratio (unique/total)
    private final int uppercaseWordCount;
    private final double uppercaseRatio;
    private final int exclamationCount;
    private final int questionCount;
    private final int firstPersonPronounCount; // I, me, my, we (overused in fake reviews)
    private final int secondPersonPronounCount; // you, your
    private final int thirdPersonPronounCount; // he, she, it, they
    private final int extremePraiseCount; // "best ever", "miracle", "perfection"
    private final int extremeNegativeCount; // "scam", "worst ever", "garbage"
    private final double sentimentScore; // -1.0 (strongly negative) to +1.0 (strongly positive)
    private final double emotionalIntensity; // Degree of polarized sentiment
    private final double repetitionScore; // Measure of duplicate n-grams or repeated words
    private final double averageWordLength;
    private final double readabilityScore; // Automated Readability Index approximation

    public LinguisticFeatures(
            int characterCount,
            int wordCount,
            int uniqueWordCount,
            double lexicalDiversity,
            int uppercaseWordCount,
            double uppercaseRatio,
            int exclamationCount,
            int questionCount,
            int firstPersonPronounCount,
            int secondPersonPronounCount,
            int thirdPersonPronounCount,
            int extremePraiseCount,
            int extremeNegativeCount,
            double sentimentScore,
            double emotionalIntensity,
            double repetitionScore,
            double averageWordLength,
            double readabilityScore) {
        this.characterCount = characterCount;
        this.wordCount = wordCount;
        this.uniqueWordCount = uniqueWordCount;
        this.lexicalDiversity = lexicalDiversity;
        this.uppercaseWordCount = uppercaseWordCount;
        this.uppercaseRatio = uppercaseRatio;
        this.exclamationCount = exclamationCount;
        this.questionCount = questionCount;
        this.firstPersonPronounCount = firstPersonPronounCount;
        this.secondPersonPronounCount = secondPersonPronounCount;
        this.thirdPersonPronounCount = thirdPersonPronounCount;
        this.extremePraiseCount = extremePraiseCount;
        this.extremeNegativeCount = extremeNegativeCount;
        this.sentimentScore = sentimentScore;
        this.emotionalIntensity = emotionalIntensity;
        this.repetitionScore = repetitionScore;
        this.averageWordLength = averageWordLength;
        this.readabilityScore = readabilityScore;
    }

    public int getCharacterCount() { return characterCount; }
    public int getWordCount() { return wordCount; }
    public int getUniqueWordCount() { return uniqueWordCount; }
    public double getLexicalDiversity() { return lexicalDiversity; }
    public int getUppercaseWordCount() { return uppercaseWordCount; }
    public double getUppercaseRatio() { return uppercaseRatio; }
    public int getExclamationCount() { return exclamationCount; }
    public int getQuestionCount() { return questionCount; }
    public int getFirstPersonPronounCount() { return firstPersonPronounCount; }
    public int getSecondPersonPronounCount() { return secondPersonPronounCount; }
    public int getThirdPersonPronounCount() { return thirdPersonPronounCount; }
    public int getExtremePraiseCount() { return extremePraiseCount; }
    public int getExtremeNegativeCount() { return extremeNegativeCount; }
    public double getSentimentScore() { return sentimentScore; }
    public double getEmotionalIntensity() { return emotionalIntensity; }
    public double getRepetitionScore() { return repetitionScore; }
    public double getAverageWordLength() { return averageWordLength; }
    public double getReadabilityScore() { return readabilityScore; }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("characterCount", characterCount);
        map.put("wordCount", wordCount);
        map.put("uniqueWordCount", uniqueWordCount);
        map.put("lexicalDiversity", Math.round(lexicalDiversity * 1000.0) / 10.0);
        map.put("uppercaseWordCount", uppercaseWordCount);
        map.put("uppercaseRatio", Math.round(uppercaseRatio * 1000.0) / 10.0);
        map.put("exclamationCount", exclamationCount);
        map.put("questionCount", questionCount);
        map.put("firstPersonPronounCount", firstPersonPronounCount);
        map.put("secondPersonPronounCount", secondPersonPronounCount);
        map.put("thirdPersonPronounCount", thirdPersonPronounCount);
        map.put("extremePraiseCount", extremePraiseCount);
        map.put("extremeNegativeCount", extremeNegativeCount);
        map.put("sentimentScore", Math.round(sentimentScore * 100.0) / 100.0);
        map.put("emotionalIntensity", Math.round(emotionalIntensity * 100.0) / 100.0);
        map.put("repetitionScore", Math.round(repetitionScore * 1000.0) / 10.0);
        map.put("averageWordLength", Math.round(averageWordLength * 10.0) / 10.0);
        map.put("readabilityScore", Math.round(readabilityScore * 10.0) / 10.0);
        return map;
    }
}
