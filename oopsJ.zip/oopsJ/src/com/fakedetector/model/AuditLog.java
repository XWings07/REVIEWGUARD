package com.fakedetector.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Audit log entry capturing security and review activity for the system owner.
 * Records: Who logged in/registered, when they acted, and what reviews were submitted.
 */
public class AuditLog {
    private final String id;
    private final long timestamp;
    private final String userId;
    private final String username;
    private final String action; // "USER_REGISTER", "USER_LOGIN", "REVIEW_ANALYZED", "BATCH_ANALYZED", "HISTORY_CLEARED"
    private final String details;
    private final String ipAddress;

    public AuditLog(String userId, String username, String action, String details, String ipAddress) {
        this(UUID.randomUUID().toString().substring(0, 8), System.currentTimeMillis(), 
             userId, username, action, details, ipAddress);
    }

    public AuditLog(String id, long timestamp, String userId, String username, String action, String details, String ipAddress) {
        this.id = id;
        this.timestamp = timestamp;
        this.userId = userId != null ? userId : "guest";
        this.username = username != null ? username : "Anonymous / Guest";
        this.action = action;
        this.details = details != null ? details : "";
        this.ipAddress = ipAddress != null ? ipAddress : "127.0.0.1";
    }

    public String getId() { return id; }
    public long getTimestamp() { return timestamp; }
    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getAction() { return action; }
    public String getDetails() { return details; }
    public String getIpAddress() { return ipAddress; }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("timestamp", timestamp);
        map.put("userId", userId);
        map.put("username", username);
        map.put("action", action);
        map.put("details", details);
        map.put("ipAddress", ipAddress);
        return map;
    }
}
