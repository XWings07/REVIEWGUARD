package com.fakedetector.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a token or phrase highlight with its deceptive/genuine significance.
 */
public class WordHighlight {
    private final String text;
    private final String type; // "fake_cue", "genuine_cue", "neutral", "exclamation"
    private final String reason;
    private final double weight;

    public WordHighlight(String text, String type, String reason, double weight) {
        this.text = text;
        this.type = type;
        this.reason = reason;
        this.weight = weight;
    }

    public String getText() { return text; }
    public String getType() { return type; }
    public String getReason() { return reason; }
    public double getWeight() { return weight; }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("text", text);
        map.put("type", type);
        map.put("reason", reason);
        map.put("weight", weight);
        return map;
    }
}
