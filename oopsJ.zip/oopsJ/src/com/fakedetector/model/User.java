package com.fakedetector.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * User account model representing registered users and owners/administrators.
 */
public class User {
    private final String id;
    private final String username;
    private final String email;
    private final String password;
    private final String role; // "ADMIN" (Owner) or "USER"
    private final long createdAt;
    private long lastLoginAt;

    public User(String username, String email, String password, String role) {
        this(UUID.randomUUID().toString().substring(0, 8), username, email, password, role, 
             System.currentTimeMillis(), System.currentTimeMillis());
    }

    public User(String id, String username, String email, String password, String role, long createdAt, long lastLoginAt) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.role = role != null ? role.toUpperCase() : "USER";
        this.createdAt = createdAt;
        this.lastLoginAt = lastLoginAt;
    }

    public String getId() { return id; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public long getCreatedAt() { return createdAt; }
    public long getLastLoginAt() { return lastLoginAt; }

    public void setLastLoginAt(long lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(role) || "OWNER".equalsIgnoreCase(role);
    }

    /**
     * Serializes public user profile without sensitive password.
     */
    public Map<String, Object> toSafeMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("username", username);
        map.put("email", email);
        map.put("role", role);
        map.put("isAdmin", isAdmin());
        map.put("createdAt", createdAt);
        map.put("lastLoginAt", lastLoginAt);
        return map;
    }

    /**
     * Serializes for persistent storage (including password).
     */
    public Map<String, Object> toStorageMap() {
        Map<String, Object> map = toSafeMap();
        map.put("password", password);
        return map;
    }
}
