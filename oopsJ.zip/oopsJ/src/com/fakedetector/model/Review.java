package com.fakedetector.model;

import java.time.Instant;
import java.util.UUID;

/**
 * Represents an individual review submitted for detection with user attribution.
 */
public class Review {
    private final String id;
    private final String text;
    private final int rating; // 1 to 5 (0 if unstated)
    private final String source; // e.g., "Web Dashboard", "API", "Test Suite"
    private final String userId;
    private final String username;
    private final long timestamp;

    public Review(String text) {
        this(UUID.randomUUID().toString().substring(0, 8), text, 0, "Web Dashboard", "guest", "Anonymous", Instant.now().toEpochMilli());
    }

    public Review(String text, int rating) {
        this(UUID.randomUUID().toString().substring(0, 8), text, rating, "Web Dashboard", "guest", "Anonymous", Instant.now().toEpochMilli());
    }

    public Review(String text, int rating, String userId, String username) {
        this(UUID.randomUUID().toString().substring(0, 8), text, rating, "Web Dashboard", userId, username, Instant.now().toEpochMilli());
    }

    public Review(String id, String text, int rating, String source, String userId, String username, long timestamp) {
        this.id = id != null ? id : UUID.randomUUID().toString().substring(0, 8);
        this.text = text != null ? text.trim() : "";
        this.rating = rating;
        this.source = source != null ? source : "Web Dashboard";
        this.userId = userId != null ? userId : "guest";
        this.username = username != null ? username : "Anonymous";
        this.timestamp = timestamp > 0 ? timestamp : Instant.now().toEpochMilli();
    }

    public String getId() { return id; }
    public String getText() { return text; }
    public int getRating() { return rating; }
    public String getSource() { return source; }
    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public long getTimestamp() { return timestamp; }
}
