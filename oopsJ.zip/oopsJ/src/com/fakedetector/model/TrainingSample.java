package com.fakedetector.model;

/**
 * Represents a labeled review sample used for training and evaluating the detector.
 */
public class TrainingSample {
    private final String text;
    private final boolean fake;
    private final String category;

    public TrainingSample(String text, boolean fake, String category) {
        this.text = text;
        this.fake = fake;
        this.category = category;
    }

    public String getText() {
        return text;
    }

    public boolean isFake() {
        return fake;
    }

    public String getCategory() {
        return category;
    }
}
