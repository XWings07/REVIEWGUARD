package com.fakedetector.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Result DTO containing the comprehensive analysis of a review with user attribution.
 */
public class AnalysisResult {
    private final String id;
    private final String reviewText;
    private final String verdict; // "FAKE", "GENUINE", "SUSPICIOUS"
    private final double confidenceScore; // 0% - 100%
    private final double fakeProbability; // 0.0 - 1.0
    private final double genuineProbability; // 0.0 - 1.0
    private final ModelAccuracy modelAccuracy;
    private final LinguisticFeatures linguisticFeatures;
    private final List<String> flaggedIndicators;
    private final List<String> matchedDeceptivePatterns;
    private final List<String> positiveAttributes;
    private final String detailedReasoning;
    private final List<WordHighlight> wordHighlights;
    private final String userId;
    private final String username;
    private final long timestamp;
    private final long processingTimeMs;

    public AnalysisResult(
            String id,
            String reviewText,
            String verdict,
            double confidenceScore,
            double fakeProbability,
            double genuineProbability,
            ModelAccuracy modelAccuracy,
            LinguisticFeatures linguisticFeatures,
            List<String> flaggedIndicators,
            List<String> matchedDeceptivePatterns,
            List<String> positiveAttributes,
            String detailedReasoning,
            List<WordHighlight> wordHighlights,
            long timestamp,
            long processingTimeMs) {
        this(id, reviewText, verdict, confidenceScore, fakeProbability, genuineProbability,
             modelAccuracy, linguisticFeatures, flaggedIndicators, matchedDeceptivePatterns,
             positiveAttributes, detailedReasoning, wordHighlights, "guest", "Anonymous",
             timestamp, processingTimeMs);
    }

    public AnalysisResult(
            String id,
            String reviewText,
            String verdict,
            double confidenceScore,
            double fakeProbability,
            double genuineProbability,
            ModelAccuracy modelAccuracy,
            LinguisticFeatures linguisticFeatures,
            List<String> flaggedIndicators,
            List<String> matchedDeceptivePatterns,
            List<String> positiveAttributes,
            String detailedReasoning,
            List<WordHighlight> wordHighlights,
            String userId,
            String username,
            long timestamp,
            long processingTimeMs) {
        this.id = id;
        this.reviewText = reviewText;
        this.verdict = verdict;
        this.confidenceScore = confidenceScore;
        this.fakeProbability = fakeProbability;
        this.genuineProbability = genuineProbability;
        this.modelAccuracy = modelAccuracy;
        this.linguisticFeatures = linguisticFeatures;
        this.flaggedIndicators = flaggedIndicators != null ? flaggedIndicators : new ArrayList<>();
        this.matchedDeceptivePatterns = matchedDeceptivePatterns != null ? matchedDeceptivePatterns : new ArrayList<>();
        this.positiveAttributes = positiveAttributes != null ? positiveAttributes : new ArrayList<>();
        this.detailedReasoning = detailedReasoning;
        this.wordHighlights = wordHighlights != null ? wordHighlights : new ArrayList<>();
        this.userId = userId != null ? userId : "guest";
        this.username = username != null ? username : "Anonymous";
        this.timestamp = timestamp;
        this.processingTimeMs = processingTimeMs;
    }

    public String getId() { return id; }
    public String getReviewText() { return reviewText; }
    public String getVerdict() { return verdict; }
    public double getConfidenceScore() { return confidenceScore; }
    public double getFakeProbability() { return fakeProbability; }
    public double getGenuineProbability() { return genuineProbability; }
    public ModelAccuracy getModelAccuracy() { return modelAccuracy; }
    public LinguisticFeatures getLinguisticFeatures() { return linguisticFeatures; }
    public List<String> getFlaggedIndicators() { return flaggedIndicators; }
    public List<String> getMatchedDeceptivePatterns() { return matchedDeceptivePatterns; }
    public List<String> getPositiveAttributes() { return positiveAttributes; }
    public String getDetailedReasoning() { return detailedReasoning; }
    public List<WordHighlight> getWordHighlights() { return wordHighlights; }
    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public long getTimestamp() { return timestamp; }
    public long getProcessingTimeMs() { return processingTimeMs; }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("reviewText", reviewText);
        map.put("verdict", verdict);
        map.put("confidenceScore", Math.round(confidenceScore * 10.0) / 10.0);
        map.put("fakeProbability", Math.round(fakeProbability * 1000.0) / 1000.0);
        map.put("genuineProbability", Math.round(genuineProbability * 1000.0) / 1000.0);
        map.put("modelAccuracy", modelAccuracy != null ? modelAccuracy.toMap() : null);
        map.put("linguisticFeatures", linguisticFeatures != null ? linguisticFeatures.toMap() : null);
        map.put("flaggedIndicators", flaggedIndicators);
        map.put("matchedDeceptivePatterns", matchedDeceptivePatterns);
        map.put("positiveAttributes", positiveAttributes);
        map.put("detailedReasoning", detailedReasoning);

        List<Map<String, Object>> highlightsList = new ArrayList<>();
        for (WordHighlight wh : wordHighlights) {
            highlightsList.add(wh.toMap());
        }
        map.put("wordHighlights", highlightsList);

        map.put("userId", userId);
        map.put("username", username);
        map.put("timestamp", timestamp);
        map.put("processingTimeMs", processingTimeMs);
        return map;
    }
}
