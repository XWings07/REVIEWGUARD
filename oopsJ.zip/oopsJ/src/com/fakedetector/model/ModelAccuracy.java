package com.fakedetector.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Tracks the evaluated accuracy and statistical performance metrics of the classifier.
 */
public class ModelAccuracy {
    private final double accuracy;
    private final double precision;
    private final double recall;
    private final double f1Score;
    private final int totalSamples;
    private final int truePositives;
    private final int falsePositives;
    private final int trueNegatives;
    private final int falseNegatives;

    public ModelAccuracy(
            double accuracy,
            double precision,
            double recall,
            double f1Score,
            int totalSamples,
            int truePositives,
            int falsePositives,
            int trueNegatives,
            int falseNegatives) {
        this.accuracy = accuracy;
        this.precision = precision;
        this.recall = recall;
        this.f1Score = f1Score;
        this.totalSamples = totalSamples;
        this.truePositives = truePositives;
        this.falsePositives = falsePositives;
        this.trueNegatives = trueNegatives;
        this.falseNegatives = falseNegatives;
    }

    public double getAccuracy() { return accuracy; }
    public double getPrecision() { return precision; }
    public double getRecall() { return recall; }
    public double getF1Score() { return f1Score; }
    public int getTotalSamples() { return totalSamples; }
    public int getTruePositives() { return truePositives; }
    public int getFalsePositives() { return falsePositives; }
    public int getTrueNegatives() { return trueNegatives; }
    public int getFalseNegatives() { return falseNegatives; }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("accuracy", Math.round(accuracy * 1000.0) / 10.0);
        map.put("precision", Math.round(precision * 1000.0) / 10.0);
        map.put("recall", Math.round(recall * 1000.0) / 10.0);
        map.put("f1Score", Math.round(f1Score * 1000.0) / 10.0);
        map.put("totalSamples", totalSamples);
        map.put("truePositives", truePositives);
        map.put("falsePositives", falsePositives);
        map.put("trueNegatives", trueNegatives);
        map.put("falseNegatives", falseNegatives);
        return map;
    }
}
