package com.fakedetector.service;

import com.fakedetector.data.AuditLogRepository;
import com.fakedetector.data.UserRepository;
import com.fakedetector.model.User;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service managing user authentication, registration, session tokens, and security audits.
 */
public class AuthService {

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final Map<String, User> activeSessions = new ConcurrentHashMap<>();

    public AuthService(UserRepository userRepository, AuditLogRepository auditLogRepository) {
        this.userRepository = userRepository;
        this.auditLogRepository = auditLogRepository;
    }

    public synchronized Map<String, Object> register(String username, String email, String password, String ipAddress) {
        User user = userRepository.register(username, email, password, "USER");
        String token = UUID.randomUUID().toString();
        activeSessions.put(token, user);

        auditLogRepository.log(user.getId(), user.getUsername(), "USER_REGISTER", 
            "New account created with email: " + user.getEmail(), ipAddress);

        Map<String, Object> resp = user.toSafeMap();
        resp.put("token", token);
        return resp;
    }

    public synchronized Map<String, Object> login(String username, String password, String ipAddress) {
        User user = userRepository.authenticate(username, password);
        if (user == null) {
            auditLogRepository.log("unknown", username, "LOGIN_FAILED", 
                "Failed login attempt for username: " + username, ipAddress);
            throw new IllegalArgumentException("Invalid username or password.");
        }

        String token = UUID.randomUUID().toString();
        activeSessions.put(token, user);

        auditLogRepository.log(user.getId(), user.getUsername(), "USER_LOGIN", 
            "User logged in (" + user.getRole() + ")", ipAddress);

        Map<String, Object> resp = user.toSafeMap();
        resp.put("token", token);
        return resp;
    }

    public void logout(String token, String ipAddress) {
        if (token != null) {
            User user = activeSessions.remove(token);
            if (user != null) {
                auditLogRepository.log(user.getId(), user.getUsername(), "USER_LOGOUT", 
                    "User logged out", ipAddress);
            }
        }
    }

    public User getUserByToken(String token) {
        if (token == null || token.trim().isEmpty()) return null;
        return activeSessions.get(token.trim());
    }

    public UserRepository getUserRepository() {
        return userRepository;
    }

    public AuditLogRepository getAuditLogRepository() {
        return auditLogRepository;
    }
}
