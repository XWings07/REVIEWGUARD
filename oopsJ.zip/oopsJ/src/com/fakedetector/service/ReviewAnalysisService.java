package com.fakedetector.service;

import com.fakedetector.data.AuditLogRepository;
import com.fakedetector.data.DatasetRepository;
import com.fakedetector.data.ReviewHistoryRepository;
import com.fakedetector.data.UserRepository;
import com.fakedetector.ml.HybridEnsembleDetector;
import com.fakedetector.model.AnalysisResult;
import com.fakedetector.model.ModelAccuracy;
import com.fakedetector.model.Review;
import com.fakedetector.model.TrainingSample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Core business service orchestrating review ingestion, NLP feature extraction,
 * ensemble inference, persistence, user segregation, and owner audit logging.
 */
public class ReviewAnalysisService {

    private final DatasetRepository datasetRepository;
    private final ReviewHistoryRepository historyRepository;
    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final AuthService authService;
    private final HybridEnsembleDetector detector;

    public ReviewAnalysisService() {
        this.datasetRepository = new DatasetRepository();
        this.historyRepository = new ReviewHistoryRepository();
        this.userRepository = new UserRepository();
        this.auditLogRepository = new AuditLogRepository();
        this.authService = new AuthService(userRepository, auditLogRepository);
        this.detector = new HybridEnsembleDetector();
        initializeModel();
    }

    private void initializeModel() {
        List<TrainingSample> samples = datasetRepository.getAllSamples();
        detector.trainAndEvaluate(samples);
    }

    public AnalysisResult analyze(String text, int rating) {
        return analyze(text, rating, "guest", "Anonymous", "127.0.0.1");
    }

    public AnalysisResult analyze(String text, int rating, String userId, String username, String ipAddress) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("Review text cannot be empty.");
        }
        Review review = new Review(text, rating, userId, username);
        AnalysisResult result = detector.analyze(review);
        historyRepository.add(result);

        // Security & Activity Audit Log for the Owner
        String snippet = text.length() > 60 ? text.substring(0, 60) + "..." : text;
        String logDetails = "Verdict: " + result.getVerdict() + " (" + Math.round(result.getConfidenceScore()) + "%) | \"" + snippet + "\"";
        auditLogRepository.log(userId, username, "REVIEW_ANALYZED", logDetails, ipAddress);

        return result;
    }

    public List<AnalysisResult> analyzeBatch(List<String> reviews, String userId, String username, String ipAddress) {
        List<AnalysisResult> results = new ArrayList<>();
        if (reviews == null) return results;
        for (String r : reviews) {
            if (r != null && !r.trim().isEmpty()) {
                results.add(analyze(r, 0, userId, username, ipAddress));
            }
        }
        auditLogRepository.log(userId, username, "BATCH_AUDITED", 
            "Audited batch of " + results.size() + " reviews", ipAddress);
        return results;
    }

    public synchronized ModelAccuracy retrainWithNewSample(String text, boolean fake, String category) {
        datasetRepository.addSample(new TrainingSample(text, fake, category));
        detector.trainAndEvaluate(datasetRepository.getAllSamples());
        return detector.getCachedAccuracy();
    }

    public List<AnalysisResult> getHistory(String userId) {
        return historyRepository.getByUserId(userId);
    }

    public List<AnalysisResult> getAllHistory() {
        return historyRepository.getAll();
    }

    public void clearHistory(String userId) {
        historyRepository.clearByUser(userId);
    }

    public void clearAllHistory() {
        historyRepository.clear();
    }

    public Map<String, Object> getDashboardStats() {
        return getDashboardStats(null);
    }

    public Map<String, Object> getDashboardStats(String userId) {
        Map<String, Object> stats = new HashMap<>(historyRepository.getAggregateStats(userId));
        stats.put("modelAccuracy", detector.getCachedAccuracy() != null ? detector.getCachedAccuracy().toMap() : null);
        stats.put("datasetSize", datasetRepository.getCount());
        return stats;
    }

    public List<TrainingSample> getDatasetSamples() {
        return datasetRepository.getAllSamples();
    }

    public ModelAccuracy getModelAccuracy() {
        return detector.getCachedAccuracy();
    }

    public AuthService getAuthService() {
        return authService;
    }

    public UserRepository getUserRepository() {
        return userRepository;
    }

    public AuditLogRepository getAuditLogRepository() {
        return auditLogRepository;
    }
}
