/**
 * ReviewGuard — Admin & Model Intelligence Portal Controller
 * Manages Administrator Authentication, Security Audit Logs, User Accounts,
 * Master Review History, and Dynamic Model Retraining.
 */

document.addEventListener('DOMContentLoaded', () => {
  // State
  let adminToken = localStorage.getItem('reviewguard_admin_token') || localStorage.getItem('veritas_token') || null;
  let currentAdmin = null;
  let cachedLogs = [];
  let cachedDataset = [];

  // DOM Elements - Login Gate
  const adminLoginGate = document.getElementById('adminLoginGate');
  const adminDashboardContent = document.getElementById('adminDashboardContent');
  const adminLoginForm = document.getElementById('adminLoginForm');
  const adminUsernameInput = document.getElementById('adminUsernameInput');
  const adminPasswordInput = document.getElementById('adminPasswordInput');
  const adminLoginSubmitBtn = document.getElementById('adminLoginSubmitBtn');
  const adminLoginSpinner = document.getElementById('adminLoginSpinner');
  const adminLoginSubmitText = document.getElementById('adminLoginSubmitText');

  // DOM Elements - Top Bar & Profile
  const adminUserBar = document.getElementById('adminUserBar');
  const adminNameLabel = document.getElementById('adminNameLabel');
  const adminLogoutBtn = document.getElementById('adminLogoutBtn');
  const adminNavTabs = document.getElementById('adminNavTabs');

  // DOM Elements - Stats Strip
  const admTotalUsers = document.getElementById('admTotalUsers');
  const admTotalEvents = document.getElementById('admTotalEvents');
  const admFakeCaught = document.getElementById('admFakeCaught');
  const admGenuineReviews = document.getElementById('admGenuineReviews');

  // DOM Elements - Logs
  const adminAuditTableBody = document.getElementById('adminAuditTableBody');
  const refreshAdminLogsBtn = document.getElementById('refreshAdminLogsBtn');
  const downloadAuditJsonBtn = document.getElementById('downloadAuditJsonBtn');
  const logSearchInput = document.getElementById('logSearchInput');
  const logActionFilter = document.getElementById('logActionFilter');

  // DOM Elements - Users
  const adminUsersTableBody = document.getElementById('adminUsersTableBody');
  const refreshUsersBtn = document.getElementById('refreshUsersBtn');

  // DOM Elements - Model Analytics
  const admEvalAccuracy = document.getElementById('admEvalAccuracy');
  const admEvalPrecision = document.getElementById('admEvalPrecision');
  const admEvalRecall = document.getElementById('admEvalRecall');
  const admEvalF1 = document.getElementById('admEvalF1');

  // DOM Elements - Dataset & Retraining
  const admDatasetCountBadge = document.getElementById('admDatasetCountBadge');
  const admDatasetTableBody = document.getElementById('admDatasetTableBody');
  const datasetFilterCategory = document.getElementById('datasetFilterCategory');
  const datasetFilterLabel = document.getElementById('datasetFilterLabel');
  const admNewSampleText = document.getElementById('admNewSampleText');
  const admNewSampleLabel = document.getElementById('admNewSampleLabel');
  const admNewSampleCategory = document.getElementById('admNewSampleCategory');
  const admAddSampleBtn = document.getElementById('admAddSampleBtn');
  const admRetrainSpinner = document.getElementById('admRetrainSpinner');
  const admRetrainText = document.getElementById('admRetrainText');

  // DOM Elements - All Reviews
  const admAllReviewsTableBody = document.getElementById('admAllReviewsTableBody');
  const refreshAllReviewsBtn = document.getElementById('refreshAllReviewsBtn');

  // Initialize
  checkAdminSession();

  // --- TAB NAVIGATION ---
  if (adminNavTabs) {
    adminNavTabs.addEventListener('click', (e) => {
      const tabBtn = e.target.closest('.nav-tab');
      if (!tabBtn) return;
      
      const targetId = tabBtn.getAttribute('data-tab');
      if (!targetId) return;

      adminNavTabs.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
      tabBtn.classList.add('active');

      document.querySelectorAll('#adminDashboardContent .tab-pane').forEach(p => p.classList.remove('active'));
      const activePane = document.getElementById(targetId);
      if (activePane) activePane.classList.add('active');
    });
  }

  // --- LOGIN SUBMIT ---
  const quickAdminFillBtn = document.getElementById('quickAdminFillBtn');
  if (quickAdminFillBtn) {
    quickAdminFillBtn.addEventListener('click', () => {
      adminUsernameInput.value = 'admin';
      adminPasswordInput.value = 'admin123';
      if (adminLoginForm) {
        adminLoginForm.dispatchEvent(new Event('submit'));
      }
    });
  }

  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = adminUsernameInput.value.trim();
      const password = adminPasswordInput.value;

      if (!username || !password) {
        showToast('Please enter both admin username and password.', 'error');
        return;
      }

      setLoginLoading(true);
      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        const token = data.token;
        const role = data.role || (data.user && data.user.role);
        const isAdmin = data.isAdmin === true || role === 'ADMIN' || role === 'OWNER' || (data.user && data.user.isAdmin);

        if (res.ok && token) {
          if (!isAdmin) {
            showToast('Access Denied: This account does not have Administrator privileges.', 'error');
            setLoginLoading(false);
            return;
          }

          adminToken = token;
          localStorage.setItem('reviewguard_admin_token', adminToken);
          localStorage.setItem('veritas_token', adminToken);
          currentAdmin = data.user || data;

          showToast('Administrator authenticated successfully.', 'success');
          showAdminDashboard();
        } else {
          showToast(data.error || 'Invalid credentials. Default is admin / admin123', 'error');
        }
      } catch (err) {
        showToast('Connection error. Is the server running?', 'error');
      } finally {
        setLoginLoading(false);
      }
    });
  }

  // --- LOGOUT ---
  if (adminLogoutBtn) {
    adminLogoutBtn.addEventListener('click', async () => {
      if (adminToken) {
        try {
          await fetch('/api/auth/logout', {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + adminToken }
          });
        } catch (ignored) {}
      }
      adminToken = null;
      currentAdmin = null;
      localStorage.removeItem('reviewguard_admin_token');
      localStorage.removeItem('veritas_token');
      showLoginGate();
      showToast('Signed out of Admin Portal.', 'info');
    });
  }

  // --- SESSION CHECK ---
  async function checkAdminSession() {
    if (!adminToken) {
      showLoginGate();
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': 'Bearer ' + adminToken }
      });
      if (res.ok) {
        const user = await res.json();
        const isAdmin = user && (user.isAdmin === true || user.role === 'ADMIN' || user.role === 'OWNER');
        if (isAdmin) {
          currentAdmin = user;
          showAdminDashboard();
          return;
        }
      }
    } catch (e) {}

    showLoginGate();
  }

  function showLoginGate() {
    if (adminLoginGate) adminLoginGate.classList.remove('hidden');
    if (adminDashboardContent) adminDashboardContent.classList.add('hidden');
    if (adminUserBar) adminUserBar.classList.add('hidden');
    if (adminNavTabs) adminNavTabs.classList.add('hidden');
  }

  function showAdminDashboard() {
    if (adminLoginGate) adminLoginGate.classList.add('hidden');
    if (adminDashboardContent) adminDashboardContent.classList.remove('hidden');
    if (adminUserBar) adminUserBar.classList.remove('hidden');
    if (adminNavTabs) adminNavTabs.classList.remove('hidden');
    if (adminNameLabel && currentAdmin) adminNameLabel.textContent = currentAdmin.username;

    // Load All Admin Data Feeds
    loadAdminLogs();
    loadAdminUsers();
    loadAdminStats();
    loadAdminDataset();
    loadAdminAllReviews();
  }

  // --- DATA LOADERS ---

  // 1. Audit & Login Logs
  async function loadAdminLogs() {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/logs', {
        headers: { 'Authorization': 'Bearer ' + adminToken }
      });
      if (res.ok) {
        cachedLogs = await res.json();
        renderAuditLogs(cachedLogs);
      } else {
        adminAuditTableBody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Failed to load logs. Session expired.</td></tr>';
      }
    } catch (err) {
      adminAuditTableBody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error fetching audit logs.</td></tr>';
    }
  }

  function renderAuditLogs(logs) {
    if (!adminAuditTableBody) return;
    if (!logs || logs.length === 0) {
      adminAuditTableBody.innerHTML = '<tr><td colspan="5" class="text-center">No audit records logged yet.</td></tr>';
      return;
    }

    // Filter by action & search query
    const filterAction = logActionFilter ? logActionFilter.value : 'ALL';
    const query = logSearchInput ? logSearchInput.value.toLowerCase().trim() : '';

    const filtered = logs.filter(item => {
      if (filterAction !== 'ALL' && item.action !== filterAction) return false;
      if (query) {
        const textToSearch = ((item.username || '') + ' ' + (item.ipAddress || '') + ' ' + (item.payload || '')).toLowerCase();
        if (!textToSearch.includes(query)) return false;
      }
      return true;
    });

    if (filtered.length === 0) {
      adminAuditTableBody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No logs match the current filter criteria.</td></tr>';
      return;
    }

    adminAuditTableBody.innerHTML = filtered.map(log => {
      const dateStr = log.timestamp ? new Date(log.timestamp).toLocaleString() : 'Just now';
      let actionClass = 'badge-neutral';
      if (log.action === 'USER_LOGIN') actionClass = 'tag-genuine';
      else if (log.action === 'USER_REGISTER') actionClass = 'tag-cyan';
      else if (log.action === 'REVIEW_ANALYZED') actionClass = 'tag-indigo';
      else if (log.action === 'BATCH_AUDITED') actionClass = 'tag-suspicious';

      return `
        <tr>
          <td><code class="text-muted">${escapeHtml(dateStr)}</code></td>
          <td><strong>${escapeHtml(log.username || 'guest')}</strong></td>
          <td><span class="badge-tag ${actionClass}">${escapeHtml(log.action || '-')}</span></td>
          <td class="snippet-cell" title="${escapeHtml(log.payload || '')}">${escapeHtml(log.payload || '-')}</td>
          <td><code class="ip-code">${escapeHtml(log.ipAddress || '127.0.0.1')}</code></td>
        </tr>
      `;
    }).join('');
  }

  // 2. Users Directory
  async function loadAdminUsers() {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/users', {
        headers: { 'Authorization': 'Bearer ' + adminToken }
      });
      if (res.ok) {
        const users = await res.json();
        renderAdminUsers(users);
        if (admTotalUsers) admTotalUsers.textContent = users.length;
      }
    } catch (err) {}
  }

  function renderAdminUsers(users) {
    if (!adminUsersTableBody) return;
    if (!users || users.length === 0) {
      adminUsersTableBody.innerHTML = '<tr><td colspan="6" class="text-center">No registered users found.</td></tr>';
      return;
    }

    adminUsersTableBody.innerHTML = users.map(u => {
      const regDate = u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'Initial';
      const lastAct = u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : 'Never';
      const roleBadge = u.isAdmin ? '<span class="badge-admin">Admin</span>' : '<span class="badge-member">Member</span>';

      return `
        <tr>
          <td><code>${escapeHtml((u.id || '').substring(0, 8))}</code></td>
          <td><strong>${escapeHtml(u.username)}</strong></td>
          <td>${escapeHtml(u.email || 'None')}</td>
          <td>${roleBadge}</td>
          <td><span class="text-muted">${regDate}</span></td>
          <td><span class="text-muted">${lastAct}</span></td>
        </tr>
      `;
    }).join('');
  }

  // 3. System Stats & Model Evaluation
  async function loadAdminStats() {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) {
        const stats = await res.json();
        if (admTotalEvents) admTotalEvents.textContent = stats.totalScanned || '0';
        if (admFakeCaught) admFakeCaught.textContent = stats.fakeCount || '0';
        if (admGenuineReviews) admGenuineReviews.textContent = stats.genuineCount || '0';

        if (stats.modelAccuracy) {
          const acc = stats.modelAccuracy;
          if (admEvalAccuracy) admEvalAccuracy.textContent = Math.round(acc.accuracy * 1000) / 10 + '%';
          if (admEvalPrecision) admEvalPrecision.textContent = Math.round(acc.precision * 1000) / 10 + '%';
          if (admEvalRecall) admEvalRecall.textContent = Math.round(acc.recall * 1000) / 10 + '%';
          if (admEvalF1) admEvalF1.textContent = Math.round(acc.f1Score * 1000) / 10 + '%';
        }
      }
    } catch (err) {}
  }

  // 4. Dataset & Retraining
  async function loadAdminDataset() {
    try {
      const res = await fetch('/api/dataset');
      if (res.ok) {
        const data = await res.json();
        cachedDataset = data.samples || [];
        if (admDatasetCountBadge) admDatasetCountBadge.textContent = cachedDataset.length + ' Samples';
        
        // Populate category dropdown
        if (datasetFilterCategory && data.categories) {
          const currentVal = datasetFilterCategory.value;
          datasetFilterCategory.innerHTML = '<option value="ALL">All Categories</option>' +
            data.categories.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
          datasetFilterCategory.value = currentVal;
        }

        renderDataset();
      }
    } catch (err) {}
  }

  function renderDataset() {
    if (!admDatasetTableBody) return;
    const cat = datasetFilterCategory ? datasetFilterCategory.value : 'ALL';
    const lbl = datasetFilterLabel ? datasetFilterLabel.value : 'ALL';

    const filtered = cachedDataset.filter(item => {
      if (cat !== 'ALL' && item.category !== cat) return false;
      if (lbl === 'FAKE' && !item.fake) return false;
      if (lbl === 'GENUINE' && item.fake) return false;
      return true;
    });

    if (filtered.length === 0) {
      admDatasetTableBody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No samples found for selected filter.</td></tr>';
      return;
    }

    admDatasetTableBody.innerHTML = filtered.map(item => `
      <tr>
        <td><span class="badge-category">${escapeHtml(item.category || 'General')}</span></td>
        <td>
          <span class="badge-tag ${item.fake ? 'tag-fake' : 'tag-genuine'}">
            ${item.fake ? 'FAKE' : 'GENUINE'}
          </span>
        </td>
        <td class="snippet-cell" title="${escapeHtml(item.text)}">${escapeHtml(item.text)}</td>
      </tr>
    `).join('');
  }

  // Add Sample & Retrain
  if (admAddSampleBtn) {
    admAddSampleBtn.addEventListener('click', async () => {
      const text = admNewSampleText.value.trim();
      const fake = admNewSampleLabel.value === 'true';
      const category = admNewSampleCategory.value.trim() || 'General';

      if (!text) {
        showToast('Please enter sample text to retrain the model.', 'error');
        return;
      }

      admRetrainSpinner.classList.remove('hidden');
      admRetrainText.textContent = 'Retraining Naive Bayes Model...';
      admAddSampleBtn.disabled = true;

      try {
        const res = await fetch('/api/dataset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, fake, category })
        });
        const result = await res.json();

        if (res.ok) {
          showToast('Sample added! Model successfully retrained.', 'success');
          admNewSampleText.value = '';
          loadAdminDataset();
          loadAdminStats();
        } else {
          showToast(result.error || 'Failed to retrain model.', 'error');
        }
      } catch (err) {
        showToast('Network error while retraining.', 'error');
      } finally {
        admRetrainSpinner.classList.add('hidden');
        admRetrainText.textContent = 'Add Sample & Retrain Model Now';
        admAddSampleBtn.disabled = false;
      }
    });
  }

  // 5. All Reviews Master Log
  async function loadAdminAllReviews() {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/all-reviews', {
        headers: { 'Authorization': 'Bearer ' + adminToken }
      });
      if (res.ok) {
        const reviews = await res.json();
        renderAllReviews(reviews);
      }
    } catch (e) {}
  }

  function renderAllReviews(reviews) {
    if (!admAllReviewsTableBody) return;
    if (!reviews || reviews.length === 0) {
      admAllReviewsTableBody.innerHTML = '<tr><td colspan="7" class="text-center">No reviews submitted across the system yet.</td></tr>';
      return;
    }

    admAllReviewsTableBody.innerHTML = reviews.map(r => {
      const dateStr = r.timestamp ? new Date(r.timestamp).toLocaleString() : '-';
      let tagClass = 'tag-suspicious';
      if (r.verdict === 'FAKE') tagClass = 'tag-fake';
      else if (r.verdict === 'GENUINE') tagClass = 'tag-genuine';

      return `
        <tr>
          <td><code>${escapeHtml(r.id || '-')}</code></td>
          <td class="snippet-cell" title="${escapeHtml(r.reviewText || '')}">${escapeHtml(r.reviewText || '-')}</td>
          <td><span class="badge-tag ${tagClass}">${escapeHtml(r.verdict)}</span></td>
          <td><strong>${Math.round((r.fakeProbability || 0) * 100)}%</strong></td>
          <td><span class="text-muted">${Math.round(r.confidenceScore || 0)}%</span></td>
          <td><strong>${escapeHtml(r.username || 'guest')}</strong></td>
          <td><span class="text-muted">${dateStr}</span></td>
        </tr>
      `;
    }).join('');
  }

  // --- EVENT LISTENERS ---
  if (refreshAdminLogsBtn) refreshAdminLogsBtn.addEventListener('click', () => { loadAdminLogs(); showToast('Logs refreshed.', 'info'); });
  if (refreshUsersBtn) refreshUsersBtn.addEventListener('click', () => { loadAdminUsers(); showToast('Users refreshed.', 'info'); });
  if (refreshAllReviewsBtn) refreshAllReviewsBtn.addEventListener('click', () => { loadAdminAllReviews(); showToast('Reviews refreshed.', 'info'); });

  if (logSearchInput) logSearchInput.addEventListener('input', () => renderAuditLogs(cachedLogs));
  if (logActionFilter) logActionFilter.addEventListener('change', () => renderAuditLogs(cachedLogs));
  if (datasetFilterCategory) datasetFilterCategory.addEventListener('change', renderDataset);
  if (datasetFilterLabel) datasetFilterLabel.addEventListener('change', renderDataset);

  // Export JSON Log Download
  if (downloadAuditJsonBtn) {
    downloadAuditJsonBtn.addEventListener('click', () => {
      if (!cachedLogs || cachedLogs.length === 0) {
        showToast('No audit logs available to export.', 'info');
        return;
      }
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(cachedLogs, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "reviewguard_audit_logs_" + new Date().toISOString().slice(0, 10) + ".json");
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showToast('Audit log exported to JSON file.', 'success');
    });
  }

  // Helpers
  function setLoginLoading(loading) {
    if (adminLoginSubmitBtn) adminLoginSubmitBtn.disabled = loading;
    if (adminLoginSpinner) adminLoginSpinner.classList.toggle('hidden', !loading);
    if (adminLoginSubmitText) adminLoginSubmitText.textContent = loading ? 'Authenticating...' : 'Sign In to Admin Portal';
  }

  function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.className = 'toast toast-' + type;
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 3500);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});

