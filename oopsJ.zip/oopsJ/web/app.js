/**
 * VeritasAI — Frontend Application Controller with Authentication & Owner Surveillance
 * Connects UI Dashboard to Java Backend REST APIs
 */

document.addEventListener('DOMContentLoaded', () => {
  // --- AUTHENTICATION STATE ---
  let currentUser = null;
  let authToken = localStorage.getItem('veritas_token') || null;

  // DOM Elements - Navigation & Header
  const openAuthModalBtn = document.getElementById('openAuthModalBtn');
  const userProfileBar = document.getElementById('userProfileBar');
  const userAvatar = document.getElementById('userAvatar');
  const userNameLabel = document.getElementById('userNameLabel');
  const userRoleBadge = document.getElementById('userRoleBadge');
  const logoutBtn = document.getElementById('logoutBtn');

  // DOM Elements - Detector
  const reviewInput = document.getElementById('reviewInput');
  const ratingInput = document.getElementById('ratingInput');
  const charCount = document.getElementById('charCount');
  const clearInputBtn = document.getElementById('clearInputBtn');
  const analyzeBtn = document.getElementById('analyzeBtn');
  const btnSpinner = document.getElementById('btnSpinner');
  const btnText = document.getElementById('btnText');

  // Result Elements
  const emptyResultState = document.getElementById('emptyResultState');
  const activeResultContent = document.getElementById('activeResultContent');
  const verdictBadge = document.getElementById('verdictBadge');
  const fakeProbBar = document.getElementById('fakeProbBar');
  const fakeProbVal = document.getElementById('fakeProbVal');
  const fakeProbCaption = document.getElementById('fakeProbCaption');
  const confBar = document.getElementById('confBar');
  const confVal = document.getElementById('confVal');
  const accBar = document.getElementById('accBar');
  const accVal = document.getElementById('accVal');
  const accCaption = document.getElementById('accCaption');
  const reasoningText = document.getElementById('reasoningText');
  const flaggedTags = document.getElementById('flaggedTags');
  const genuineTags = document.getElementById('genuineTags');
  const wordHighlightContainer = document.getElementById('wordHighlightContainer');

  // Stylometric Features
  const fLexicalVal = document.getElementById('fLexicalVal');
  const fLexicalBar = document.getElementById('fLexicalBar');
  const fSentimentVal = document.getElementById('fSentimentVal');
  const fSentimentBar = document.getElementById('fSentimentBar');
  const fIntensityVal = document.getElementById('fIntensityVal');
  const fIntensityBar = document.getElementById('fIntensityBar');
  const fPronounVal = document.getElementById('fPronounVal');
  const fPronounBar = document.getElementById('fPronounBar');
  const fCapsVal = document.getElementById('fCapsVal');
  const fCapsBar = document.getElementById('fCapsBar');
  const fExclVal = document.getElementById('fExclVal');
  const fExclBar = document.getElementById('fExclBar');

  // Auth Modal Elements
  const authModal = document.getElementById('authModal');
  const closeAuthModalBtn = document.getElementById('closeAuthModalBtn');
  const modalBackdrop = document.getElementById('modalBackdrop');
  const authForm = document.getElementById('authForm');
  const tabSignInBtn = document.getElementById('tabSignInBtn');
  const tabRegisterBtn = document.getElementById('tabRegisterBtn');
  const authUsernameInput = document.getElementById('authUsernameInput');
  const authPasswordInput = document.getElementById('authPasswordInput');
  const authEmailInput = document.getElementById('authEmailInput');
  const authEmailGroup = document.getElementById('authEmailGroup');
  const authModalTitle = document.getElementById('authModalTitle');
  const authModalSubtitle = document.getElementById('authModalSubtitle');
  const authSubmitText = document.getElementById('authSubmitText');
  const authSpinner = document.getElementById('authSpinner');
  const quickAdminLoginBtn = document.getElementById('quickAdminLoginBtn');
  const quickUserLoginBtn = document.getElementById('quickUserLoginBtn');

  let isRegisterMode = false;

  // Sample Reviews Data
  const sampleReviews = {
    'fake-bot': {
      text: "BEST PRODUCT EVER A+++ BUY BUY BUY!!! CHANGED MY LIFE!! Five stars aren't enough! Unmatched quality!",
      rating: 5
    },
    'fake-sponsored': {
      text: "I received this item with a promotional discount in exchange for an honest review. As a top reviewer, this is the holy grail of all products! Pure perfection!",
      rating: 5
    },
    'fake-smear': {
      text: "DO NOT BUY TOTAL SCAM! Worst company on earth, criminals and thieves! Bounced my refund! Zero stars if I could!!",
      rating: 1
    },
    'genuine-tech': {
      text: "I've been using this keyboard for three weeks. The mechanical switches have good tactile feedback, but the spacebar has a slight rattle. Battery life lasted about 35 hours on Bluetooth before needing a recharge.",
      rating: 4
    },
    'genuine-balance': {
      text: "Solid winter coat. The stitching around the shoulders feels durable and the zipper doesn't snag. However, the sizing runs a bit small, so consider ordering one size up if you plan to wear thick sweaters.",
      rating: 4
    }
  };

  // Nav Tab Switching
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabPanes = document.querySelectorAll('.tab-pane');

  navTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetId = tab.getAttribute('data-tab');
      if (!targetId) return;

      navTabs.forEach(t => t.classList.remove('active'));
      tabPanes.forEach(p => p.classList.remove('active'));

      tab.classList.add('active');
      const pane = document.getElementById(targetId);
      if (pane) pane.classList.add('active');

      if (targetId === 'analytics-tab') loadAnalytics();
    });
  });

  // Character and Word Counter
  reviewInput.addEventListener('input', () => {
    const text = reviewInput.value.trim();
    const chars = reviewInput.value.length;
    const words = text ? text.split(/\s+/).length : 0;
    charCount.textContent = `${chars} characters • ${words} words`;
  });

  // Clear Input
  clearInputBtn.addEventListener('click', () => {
    reviewInput.value = '';
    charCount.textContent = '0 characters • 0 words';
    reviewInput.focus();
  });

  // Sample Chips Click
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const sampleKey = chip.getAttribute('data-sample');
      if (sampleReviews[sampleKey]) {
        reviewInput.value = sampleReviews[sampleKey].text;
        ratingInput.value = sampleReviews[sampleKey].rating;
        reviewInput.dispatchEvent(new Event('input'));
        triggerAnalysis();
      }
    });
  });

  // Helper: Get Auth Headers
  function getAuthHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    return headers;
  }

  // Analyze Button Click
  analyzeBtn.addEventListener('click', triggerAnalysis);

  async function triggerAnalysis() {
    const text = reviewInput.value.trim();
    if (!text) {
      showToast('Please enter or paste a review first.');
      reviewInput.focus();
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          text: text,
          rating: parseInt(ratingInput.value, 10) || 0
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned error ${response.status}`);
      }

      const data = await response.json();
      renderAnalysisResult(data);
    } catch (err) {
      console.error('Analysis failed:', err);
      showToast('Error connecting to backend server. Ensure Java server is running.');
    } finally {
      setLoading(false);
    }
  }

  function setLoading(isLoading) {
    if (isLoading) {
      btnSpinner.classList.remove('hidden');
      btnText.textContent = 'Auditing Review & NLP Cues...';
      analyzeBtn.disabled = true;
    } else {
      btnSpinner.classList.add('hidden');
      btnText.textContent = 'Detect Fake & Evaluate Accuracy';
      analyzeBtn.disabled = false;
    }
  }

  function renderAnalysisResult(data) {
    emptyResultState.classList.add('hidden');
    activeResultContent.classList.remove('hidden');

    // Verdict Badge
    verdictBadge.className = 'verdict-badge';
    if (data.verdict === 'FAKE') {
      verdictBadge.classList.add('verdict-fake');
      verdictBadge.textContent = '🚨 FAKE / DECEPTIVE SPAM';
    } else if (data.verdict === 'GENUINE') {
      verdictBadge.classList.add('verdict-genuine');
      verdictBadge.textContent = '✅ AUTHENTIC / GENUINE';
    } else {
      verdictBadge.classList.add('verdict-suspicious');
      verdictBadge.textContent = '⚠️ SUSPICIOUS / INCONCLUSIVE';
    }

    // Key Meters
    const fakePercent = Math.round(data.fakeProbability * 100);
    fakeProbVal.textContent = `${fakePercent}%`;
    fakeProbBar.style.width = `${fakePercent}%`;
    if (fakePercent > 60) {
      fakeProbVal.style.color = 'var(--color-fake)';
      fakeProbCaption.textContent = 'High confidence of deceptive opinion spam';
    } else if (fakePercent < 40) {
      fakeProbVal.style.color = 'var(--color-genuine)';
      fakeProbCaption.textContent = 'High likelihood of genuine customer experience';
    } else {
      fakeProbVal.style.color = 'var(--color-suspicious)';
      fakeProbCaption.textContent = 'Borderline / mixed indicators';
    }

    confVal.textContent = `${Math.round(data.confidenceScore)}%`;
    confBar.style.width = `${Math.round(data.confidenceScore)}%`;

    if (data.modelAccuracy) {
      const acc = data.modelAccuracy.accuracy;
      accVal.textContent = `${acc}%`;
      accBar.style.width = `${acc}%`;
      accCaption.textContent = `Precision: ${data.modelAccuracy.precision}% • Recall: ${data.modelAccuracy.recall}%`;
      document.getElementById('headerAccuracyPill').textContent = `Accuracy: ${acc}%`;
    }

    // Reasoning
    reasoningText.textContent = data.detailedReasoning;

    // Flagged Deceptive Tags
    flaggedTags.innerHTML = '';
    const allFlags = [...(data.flaggedIndicators || []), ...(data.matchedDeceptivePatterns || [])];
    if (allFlags.length > 0) {
      document.getElementById('deceptiveGroup').style.display = 'block';
      allFlags.forEach(flag => {
        const span = document.createElement('span');
        span.className = 'tag tag-fake';
        span.textContent = flag;
        flaggedTags.appendChild(span);
      });
    } else {
      document.getElementById('deceptiveGroup').style.display = 'none';
    }

    // Genuine Attributes Tags
    genuineTags.innerHTML = '';
    if (data.positiveAttributes && data.positiveAttributes.length > 0) {
      document.getElementById('genuineGroup').style.display = 'block';
      data.positiveAttributes.forEach(attr => {
        const span = document.createElement('span');
        span.className = 'tag tag-genuine';
        span.textContent = `Attribute: ${attr}`;
        genuineTags.appendChild(span);
      });
    } else {
      document.getElementById('genuineGroup').style.display = 'none';
    }

    // Stylometric Features
    const f = data.linguisticFeatures;
    if (f) {
      fLexicalVal.textContent = `${f.lexicalDiversity}%`;
      fLexicalBar.style.width = `${Math.min(100, f.lexicalDiversity)}%`;

      fSentimentVal.textContent = `${f.sentimentScore > 0 ? '+' : ''}${f.sentimentScore}`;
      const sentPct = Math.round(((f.sentimentScore + 1.0) / 2.0) * 100);
      fSentimentBar.style.width = `${sentPct}%`;

      const intensPct = Math.round(f.emotionalIntensity * 100);
      fIntensityVal.textContent = `${intensPct}%`;
      fIntensityBar.style.width = `${intensPct}%`;

      fPronounVal.textContent = `${f.firstPersonPronounCount}`;
      fPronounBar.style.width = `${Math.min(100, f.firstPersonPronounCount * 15)}%`;

      fCapsVal.textContent = `${f.uppercaseWordCount} (${f.uppercaseRatio}%)`;
      fCapsBar.style.width = `${Math.min(100, f.uppercaseRatio)}%`;

      fExclVal.textContent = `${f.exclamationCount}`;
      fExclBar.style.width = `${Math.min(100, f.exclamationCount * 20)}%`;
    }

    // Word Token Highlighter
    wordHighlightContainer.innerHTML = '';
    if (data.wordHighlights && data.wordHighlights.length > 0) {
      data.wordHighlights.forEach(wh => {
        const span = document.createElement('span');
        span.textContent = wh.text + ' ';
        if (wh.type === 'fake_cue') {
          span.className = 'tok tok-fake';
          span.title = `Deceptive Marker: ${wh.reason}`;
        } else if (wh.type === 'genuine_cue') {
          span.className = 'tok tok-real';
          span.title = `Verified Detail: ${wh.reason}`;
        } else {
          span.className = 'tok tok-neutral';
        }
        wordHighlightContainer.appendChild(span);
      });
    } else {
      wordHighlightContainer.textContent = data.reviewText;
    }
  }

  // --- BATCH AUDIT TAB ---
  const runBatchBtn = document.getElementById('runBatchBtn');
  const batchInput = document.getElementById('batchInput');
  const batchSummary = document.getElementById('batchSummary');
  const batchTotalCount = document.getElementById('batchTotalCount');
  const batchFakeCount = document.getElementById('batchFakeCount');
  const batchGenuineCount = document.getElementById('batchGenuineCount');
  const batchSuspiciousCount = document.getElementById('batchSuspiciousCount');
  const batchResultsList = document.getElementById('batchResultsList');

  runBatchBtn.addEventListener('click', async () => {
    const raw = batchInput.value.trim();
    if (!raw) {
      showToast('Please enter multiple reviews separated by empty lines.');
      return;
    }

    const reviews = raw.split(/\n\s*\n|---/).map(r => r.trim()).filter(r => r.length > 0);
    if (reviews.length === 0) return;

    runBatchBtn.disabled = true;
    runBatchBtn.textContent = 'Auditing Batch...';
    batchResultsList.innerHTML = '<p class="text-dim">Analyzing reviews, please wait...</p>';

    let fake = 0, genuine = 0, susp = 0;
    batchResultsList.innerHTML = '';

    for (const r of reviews) {
      try {
        const resp = await fetch('/api/analyze', {
          method: 'POST',
          headers: getAuthHeaders(),
          body: JSON.stringify({ text: r, rating: 0 })
        });
        const res = await resp.json();

        if (res.verdict === 'FAKE') fake++;
        else if (res.verdict === 'GENUINE') genuine++;
        else susp++;

        const item = document.createElement('div');
        item.className = 'batch-item';
        item.innerHTML = `
          <div class="batch-item-text">
            <strong>"${r.substring(0, 90)}${r.length > 90 ? '...' : ''}"</strong>
          </div>
          <div>
            <span class="verdict-badge verdict-${res.verdict.toLowerCase()}">${res.verdict} (${Math.round(res.confidenceScore)}%)</span>
          </div>
        `;
        batchResultsList.appendChild(item);
      } catch (e) {
        console.error(e);
      }
    }

    batchSummary.classList.remove('hidden');
    batchTotalCount.textContent = reviews.length;
    batchFakeCount.textContent = fake;
    batchGenuineCount.textContent = genuine;
    batchSuspiciousCount.textContent = susp;

    runBatchBtn.disabled = false;
    runBatchBtn.textContent = 'Audit All Reviews';
  });

  // --- USER HISTORY & PERSONAL STATS TAB ---
  const refreshStatsBtn = document.getElementById('refreshStatsBtn');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  const historyTableBody = document.getElementById('historyTableBody');

  refreshStatsBtn.addEventListener('click', loadAnalytics);
  clearHistoryBtn.addEventListener('click', async () => {
    if (confirm('Clear your review scan history?')) {
      await fetch('/api/history', { method: 'DELETE', headers: getAuthHeaders() });
      loadAnalytics();
      showToast('History cleared.');
    }
  });

  async function loadAnalytics() {
    try {
      const [statsRes, historyRes] = await Promise.all([
        fetch('/api/stats', { headers: getAuthHeaders() }).then(r => r.json()),
        fetch('/api/history', { headers: getAuthHeaders() }).then(r => r.json())
      ]);

      document.getElementById('statTotalScans').textContent = statsRes.totalScans || 0;
      document.getElementById('statFakeRate').textContent = `${statsRes.fakePercentage || 0}%`;
      document.getElementById('statGenuineRate').textContent = `${statsRes.genuinePercentage || 0}%`;
      document.getElementById('statAvgConfidence').textContent = `${statsRes.averageConfidence || 0}%`;

      if (currentUser) {
        document.getElementById('historySectionTitle').textContent = `${currentUser.username}'s Tracked Reviews`;
        document.getElementById('historySectionDesc').textContent = `Showing reviews submitted under account: ${currentUser.username}`;
      } else {
        document.getElementById('historySectionTitle').textContent = `Guest Session Review History`;
        document.getElementById('historySectionDesc').textContent = `Sign in to permanently save and track reviews across devices`;
      }

      if (!historyRes || historyRes.length === 0) {
        historyTableBody.innerHTML = `
          <tr><td colspan="7" class="text-center">No scans recorded yet. Run your first review detection!</td></tr>
        `;
        return;
      }

      historyTableBody.innerHTML = '';
      historyRes.forEach(item => {
        const tr = document.createElement('tr');
        const snippet = item.reviewText.length > 55 ? item.reviewText.substring(0, 55) + '...' : item.reviewText;
        const timeStr = new Date(item.timestamp).toLocaleTimeString();
        const author = item.username || 'Anonymous';

        tr.innerHTML = `
          <td><code>${item.id}</code></td>
          <td>${snippet}</td>
          <td><span class="verdict-badge verdict-${item.verdict.toLowerCase()}">${item.verdict}</span></td>
          <td>${Math.round(item.fakeProbability * 100)}%</td>
          <td>${Math.round(item.confidenceScore)}%</td>
          <td><strong>${author}</strong></td>
          <td>${timeStr}</td>
        `;
        historyTableBody.appendChild(tr);
      });
    } catch (e) {
      console.error('Failed to load analytics:', e);
    }
  }

  // --- AUTHENTICATION MODAL LOGIC ---
  openAuthModalBtn.addEventListener('click', () => openModal(false));
  closeAuthModalBtn.addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', closeModal);

  function openModal(registerMode = false) {
    isRegisterMode = registerMode;
    updateModalMode();
    authModal.classList.remove('hidden');
    authUsernameInput.focus();
  }

  function closeModal() {
    authModal.classList.add('hidden');
    authUsernameInput.value = '';
    authPasswordInput.value = '';
    authEmailInput.value = '';
  }

  tabSignInBtn.addEventListener('click', () => {
    isRegisterMode = false;
    updateModalMode();
  });

  tabRegisterBtn.addEventListener('click', () => {
    isRegisterMode = true;
    updateModalMode();
  });

  function updateModalMode() {
    if (isRegisterMode) {
      tabRegisterBtn.classList.add('active');
      tabSignInBtn.classList.remove('active');
      authEmailGroup.classList.remove('hidden');
      authModalTitle.textContent = 'Create a New Account';
      authModalSubtitle.textContent = 'Register to track your past reviews and analysis history';
      authSubmitText.textContent = 'Create Free Account';
    } else {
      tabSignInBtn.classList.add('active');
      tabRegisterBtn.classList.remove('active');
      authEmailGroup.classList.add('hidden');
      authModalTitle.textContent = 'Welcome Back to VeritasAI';
      authModalSubtitle.textContent = 'Sign in to track your personal review audits & accuracy trends';
      authSubmitText.textContent = 'Sign In to VeritasAI';
    }
  }

  // Quick 1-Click Demo Login
  quickAdminLoginBtn.addEventListener('click', () => {
    authUsernameInput.value = 'admin';
    authPasswordInput.value = 'admin123';
    isRegisterMode = false;
    updateModalMode();
    submitAuth();
  });

  quickUserLoginBtn.addEventListener('click', () => {
    authUsernameInput.value = 'reviewer';
    authPasswordInput.value = 'user123';
    isRegisterMode = false;
    updateModalMode();
    submitAuth();
  });

  authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    submitAuth();
  });

  async function submitAuth() {
    const username = authUsernameInput.value.trim();
    const password = authPasswordInput.value;
    const email = authEmailInput.value.trim();

    if (!username || !password) {
      showToast('Please enter both username and password.');
      return;
    }

    authSpinner.classList.remove('hidden');
    authSubmitBtn.disabled = true;

    try {
      const endpoint = isRegisterMode ? '/api/auth/register' : '/api/auth/login';
      const payload = isRegisterMode ? { username, password, email } : { username, password };

      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await resp.json();

      if (!resp.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      // Success
      authToken = data.token;
      localStorage.setItem('veritas_token', authToken);
      currentUser = data;

      applyUserState();
      closeModal();
      showToast(`Welcome ${data.username}! (${data.role})`);

      // Refresh history & stats for this user
      loadAnalytics();

    } catch (err) {
      console.error(err);
      showToast(err.message);
    } finally {
      authSpinner.classList.add('hidden');
      authSubmitBtn.disabled = false;
    }
  }

  logoutBtn.addEventListener('click', async () => {
    if (confirm('Sign out of your account?')) {
      try {
        await fetch('/api/auth/logout', { method: 'POST', headers: getAuthHeaders() });
      } catch (e) {}

      authToken = null;
      currentUser = null;
      localStorage.removeItem('veritas_token');
      applyUserState();
      showToast('Signed out successfully.');

      // Return to detector tab
      document.querySelector('[data-tab="detector-tab"]').click();
    }
  });

  function applyUserState() {
    if (currentUser) {
      openAuthModalBtn.classList.add('hidden');
      userProfileBar.classList.remove('hidden');
      userNameLabel.textContent = currentUser.username;
      userAvatar.textContent = currentUser.username.substring(0, 1).toUpperCase();

      if (currentUser.role === 'ADMIN') {
        userRoleBadge.textContent = 'Admin';
        userRoleBadge.className = 'user-role-badge user-role-admin';
      } else {
        userRoleBadge.textContent = 'Member';
        userRoleBadge.className = 'user-role-badge';
      }
    } else {
      openAuthModalBtn.classList.remove('hidden');
      userProfileBar.classList.add('hidden');
    }
  }

  // Check Existing Session on page load
  async function checkSession() {
    if (!authToken) {
      applyUserState();
      return;
    }

    try {
      const resp = await fetch('/api/auth/me', { headers: getAuthHeaders() });
      if (resp.ok) {
        currentUser = await resp.json();
        applyUserState();
      } else {
        // Expired token
        localStorage.removeItem('veritas_token');
        authToken = null;
        applyUserState();
      }
    } catch (e) {
      applyUserState();
    }
  }

  // Toast Helper
  function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.remove('hidden');
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 3200);
  }

  // Initialize
  checkSession();
  initBackgroundNeuralParticles();

  // Preload initial dataset metrics
  fetch('/api/stats', { headers: getAuthHeaders() })
    .then(r => r.json())
    .then(stats => {
      if (stats.modelAccuracy) {
        document.getElementById('headerAccuracyPill').textContent = `Accuracy: ${stats.modelAccuracy.accuracy}%`;
      }
    })
    .catch(() => {});

  // =========================================================================
  // CLASSY ANIMATED NEURAL NETWORK MATRIX PARTICLES
  // =========================================================================
  function initBackgroundNeuralParticles() {
    const canvas = document.getElementById('bgCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const count = Math.min(65, Math.floor((width * height) / 24000));
    const colors = ['rgba(6, 182, 212, ', 'rgba(59, 130, 246, ', 'rgba(139, 92, 246, '];

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.65,
        vy: (Math.random() - 0.5) * 0.65,
        radius: Math.random() * 2 + 1.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.5 + 0.35
      });
    }

    let mouse = { x: null, y: null };
    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    });
    window.addEventListener('mouseleave', () => {
      mouse.x = null;
      mouse.y = null;
    });

    function render() {
      ctx.clearRect(0, 0, width, height);

      // Draw dynamic neural lines
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 135) {
            const lineAlpha = (1 - dist / 135) * 0.22;
            ctx.beginPath();
            ctx.strokeStyle = `rgba(56, 189, 248, ${lineAlpha})`;
            ctx.lineWidth = 0.85;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Update and draw glowing nodes
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        if (mouse.x !== null) {
          const mdx = p.x - mouse.x;
          const mdy = p.y - mouse.y;
          const mdist = Math.sqrt(mdx * mdx + mdy * mdy);
          if (mdist < 110) {
            p.x += (mdx / mdist) * 0.7;
            p.y += (mdy / mdist) * 0.7;
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color + p.alpha + ')';
        ctx.shadowColor = '#06b6d4';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      requestAnimationFrame(render);
    }

    render();
  }
});
