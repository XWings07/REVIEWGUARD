# ReviewGuard — Fake Review Detection System

An Object-Oriented Java project for detecting deceptive opinion spam, fake reviews, and bot-generated reviews using Natural Language Processing and Machine Learning.

Built entirely in **Core Java (Java SE 11+)** with **zero external dependencies**, featuring a clean user-facing detection web application and a dedicated Administrator & Model Portal.

---

## 🚀 How to Run the Project

### Method 1: Using the Runner Script (Windows)
Double-click or run:
```cmd
run.bat
```

### Method 2: Using PowerShell
```powershell
.\run.ps1
```

### Method 3: Manual Terminal Compilation
```bash
# 1. Compile Java source files into bin/
javac -d bin -sourcepath src src/com/fakedetector/HttpServerApp.java

# 2. Start the HTTP server on port 8080
java -cp bin com.fakedetector.HttpServerApp 8080
```

Once running:
- **Public Detection Portal:** [http://localhost:8080](http://localhost:8080)
- **Admin & Model Portal:** [http://localhost:8080/admin](http://localhost:8080/admin) (or `http://localhost:8080/admin.html`)

---

## 🔑 Login Accounts

| Account Type | Username | Password | Purpose |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `admin123` | Full access to `/admin` portal: inspects user login logs, user directory, model metrics, training dataset, and live retraining. |
| **Standard User** | `reviewer` | `user123` | Standard user for testing personal scan history tracking. |
| **New Registration** | *(Custom)* | *(Custom)* | Click "Sign In / Register" on the main portal to create an account. |

---

## 🌐 Application Architecture

The system is separated into two portals:

### 1. Public Review Portal (`http://localhost:8080`)
- **Review Analyzer:** Enter review text to inspect spam probability, decision confidence, token highlights (red for deceptive patterns, green for genuine attributes), and linguistic metrics.
- **Batch Scanner:** Analyze multiple customer reviews simultaneously.
- **Scan History:** Shows personal history of reviews analyzed during the session.
- **How It Works:** Explains the text preprocessing, stylometric features, and Naive Bayes modeling.

### 2. Admin & Model Management Portal (`http://localhost:8080/admin`)
- **Login & Activity Logs:** Real-time stream of all authentication events, user registrations, review submissions, timestamps, and client IP addresses. Search and filter by event type.
- **User Directory:** List of all registered users, roles, email addresses, and last active times.
- **Model Analytics:** Live accuracy, precision, recall, and F1-score with confusion matrix breakdown.
- **Dataset & Retraining:** Inspect the training corpus and dynamically add new training samples to retrain the Naive Bayes model in memory.
- **All Reviews:** Master log of all reviews scanned by all users across the system.

---

## 📁 Source Code Organization (`src/com/fakedetector/`)

```
src/com/fakedetector/
├── HttpServerApp.java                       # Main entry point, starts Java HttpServer
│
├── model/                                   # Data models & DTOs
│   ├── User.java                            # User account entity (id, username, role, timestamps)
│   ├── AuditLog.java                        # Security event entity (user, action, payload, ip)
│   ├── Review.java                          # Review entity with author attribution
│   ├── TrainingSample.java                  # Labeled ground truth data for training
│   ├── LinguisticFeatures.java              # Container for 18 stylometric features
│   ├── ModelAccuracy.java                   # Evaluation metrics (Accuracy, Precision, Recall, F1)
│   ├── WordHighlight.java                   # Token classification for explainable UI highlighting
│   └── AnalysisResult.java                  # Master analysis DTO returned to client
│
├── nlp/                                     # Natural Language Processing
│   ├── Tokenizer.java                       # Splits words, sentences, and extracts bigrams
│   ├── StopWordFilter.java                  # Filters stopwords while preserving diagnostic pronouns
│   ├── SentimentLexicon.java                # Vocabulary dictionaries for praise, smear, and product attributes
│   └── FeatureExtractor.java                # Computes ARI, lexical diversity, uppercase ratio, emotions
│
├── ml/                                      # Machine Learning
│   ├── Classifier.java                      # Interface contract for classifiers (Polymorphism)
│   ├── MultinomialNaiveBayesClassifier.java # Laplace add-1 smoothed Naive Bayes with log likelihoods
│   ├── RuleBasedEnsembleClassifier.java     # Empirical stylometric heuristics
│   └── HybridEnsembleDetector.java          # Blends Naive Bayes + Heuristics into calibrated verdicts
│
├── data/                                    # Persistence & Repositories
│   ├── UserRepository.java                  # Manages accounts (syncs to data/users.json)
│   ├── AuditLogRepository.java              # Manages activity logs (syncs to data/audit_logs.json)
│   ├── ReviewHistoryRepository.java         # Stores review scans (syncs to data/review_history.json)
│   └── DatasetRepository.java               # Balanced training corpus with dynamic sample additions
│
├── service/                                 # Business Logic
│   ├── AuthService.java                     # Authentication, sessions, and role checks
│   └── ReviewAnalysisService.java           # Facade orchestrating NLP, ML, and storage
│
├── controller/                              # HTTP REST Handlers
│   ├── AuthHandler.java                     # /api/auth (login, register, me, logout)
│   ├── AdminHandler.java                    # /api/admin (logs, users, all-reviews)
│   ├── AnalyzeHandler.java                  # /api/analyze (review scanning)
│   ├── HistoryHandler.java                  # /api/history (user scan history)
│   ├── StatsHandler.java                    # /api/stats (aggregate metrics)
│   ├── DatasetHandler.java                  # /api/dataset (dataset view & dynamic retraining)
│   └── StaticFileHandler.java               # Serves HTML, CSS, JS frontend assets
│
└── util/
    └── JsonUtil.java                        # Zero-dependency custom JSON parser & serializer
```
