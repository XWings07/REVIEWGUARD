# ==============================================================
#    ReviewGuard — Fake Review Detection System (PowerShell)
# ==============================================================

Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "   ReviewGuard - Fake Review Detection System" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan

# 1. Check Java
Write-Host "[1/3] Checking Java environment..." -ForegroundColor Yellow
try {
    $javaVer = java -version 2>&1
    Write-Host "Found Java: $($javaVer[0])" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Java is not installed or not in PATH." -ForegroundColor Red
    exit 1
}

# 2. Compile Java classes
Write-Host "[2/3] Compiling Java sources to bin/..." -ForegroundColor Yellow
if (-not (Test-Path "bin")) {
    New-Item -ItemType Directory -Path "bin" | Out-Null
}

$compileOutput = javac -d bin -sourcepath src src/com/fakedetector/HttpServerApp.java 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Compilation failed:" -ForegroundColor Red
    Write-Host $compileOutput
    exit 1
}
Write-Host "Compilation successful!" -ForegroundColor Green

# 3. Start Backend & Open Browser
Write-Host "[3/3] Starting backend HTTP server on port 8080..." -ForegroundColor Yellow
Write-Host "Opening dashboard at http://localhost:8080 ..." -ForegroundColor Cyan

Start-Process "http://localhost:8080"
java -cp bin com.fakedetector.HttpServerApp 8080
