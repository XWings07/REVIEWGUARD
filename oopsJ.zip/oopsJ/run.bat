@echo off
title ReviewGuard — Fake Review Detection System
cls
echo ==============================================================
echo    ReviewGuard - Fake Review Detection System
echo ==============================================================
echo [1/3] Checking Java installation...

java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Java is not recognized in your PATH.
    echo Please ensure Java 11 or higher is installed.
    pause
    exit /b 1
)

echo [2/3] Compiling Java modules...
if not exist "bin" mkdir "bin"

javac -d bin -sourcepath src src/com/fakedetector/HttpServerApp.java
if %errorlevel% neq 0 (
    echo [ERROR] Compilation failed! Check error messages above.
    pause
    exit /b 1
)

echo [3/3] Starting Java Backend Server...
echo Public Portal: http://localhost:8080
echo Admin Portal:  http://localhost:8080/admin
echo Opening browser in 2 seconds...

start "" http://localhost:8080
java -cp bin com.fakedetector.HttpServerApp 8080

pause
