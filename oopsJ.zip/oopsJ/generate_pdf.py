import os
import textwrap

os.environ['MPLCONFIGDIR'] = os.path.join(os.environ.get('TEMP', '.'), 'mpl_cfg')

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.patches as patches

pdf_path = r"C:\Users\himan\OneDrive\Desktop\oopsJ\ReviewGuard_Viva_Defense_QA.pdf"

with PdfPages(pdf_path) as pdf:
    # ------------------ PAGE 1 ------------------
    fig = plt.figure(figsize=(8.27, 11.69), dpi=100) # A4 size
    ax = fig.add_axes([0, 0, 1, 1])
    ax.axis('off')

    # Header Background
    ax.add_patch(patches.Rectangle((0.05, 0.90), 0.90, 0.08, facecolor='#1e3a8a', edgecolor='none'))
    ax.text(0.07, 0.945, "ReviewGuard — Fake Review Detection System", color='white', fontsize=15, fontweight='bold', va='center')
    ax.text(0.07, 0.918, "RAPID-FIRE VIVA DEFENSE & PROJECT ARCHITECTURE SHEET (Java & OOP)", color='#93c5fd', fontsize=9.5, fontweight='bold', va='center')
    ax.text(0.93, 0.945, "Core Java (Java SE 11+)", color='#fbbf24', fontsize=9, fontweight='bold', ha='right', va='center')
    ax.text(0.93, 0.918, "Zero Dependencies | Port 8080", color='#cbd5e1', fontsize=8.5, ha='right', va='center')

    # Section 1: File-to-Work Summary Table
    y = 0.875
    ax.text(0.05, y, "1. FILE-TO-WORK QUICK REFERENCE (WHICH FILE DOES WHAT)", color='#0f172a', fontsize=11, fontweight='bold', va='center')
    ax.plot([0.05, 0.95], [y - 0.01, y - 0.01], color='#2563eb', lw=1.5)

    files_data = [
        ("run.bat / run.ps1", "1-Click launcher: verifies Java, compiles with javac into bin/, and starts server."),
        ("HttpServerApp.java", "Main entry point (main): trains model, binds native HttpServer on port 8080 (10 threads)."),
        ("HybridEnsembleDetector.java", "Core Detector: blends 55% Naive Bayes + 45% Rule-based heuristics into final verdict."),
        ("MultinomialNaiveBayesClassifier.java", "Probabilistic ML classifier with Laplace Add-1 smoothing and log-likelihood calculation."),
        ("RuleBasedEnsembleClassifier.java", "Empirical stylometric cues: hyperbole, smear attacks, incentive markers, all-caps shouting."),
        ("FeatureExtractor.java", "Extracts 18 linguistic features (lexical diversity, ARI readability, emotion intensity)."),
        ("ReviewAnalysisService.java", "Facade Pattern: coordinates NLP extraction, ML prediction, audit logs, and persistence."),
        ("JsonUtil.java", "Zero-dependency recursive-descent custom JSON parser & serializer from scratch."),
        ("UserRepository / AuditLogRepository", "Thread-safe data repositories syncing accounts & security audit trails to data/*.json.")
    ]

    ty = y - 0.03
    for filename, desc in files_data:
        ax.add_patch(patches.Rectangle((0.05, ty - 0.018), 0.28, 0.022, facecolor='#f1f5f9', edgecolor='#cbd5e1', lw=0.5))
        ax.add_patch(patches.Rectangle((0.33, ty - 0.018), 0.62, 0.022, facecolor='#ffffff', edgecolor='#cbd5e1', lw=0.5))
        ax.text(0.06, ty - 0.007, filename, fontsize=8, fontweight='bold', color='#1e3a8a', va='center')
        ax.text(0.34, ty - 0.007, desc, fontsize=7.5, color='#334155', va='center')
        ty -= 0.024

    # Section 2: Rapid-Fire Questions (Part 1)
    y2 = ty - 0.015
    ax.text(0.05, y2, "2. RAPID-FIRE QUESTIONS & SHORT ANSWERS (PART 1)", color='#0f172a', fontsize=11, fontweight='bold', va='center')
    ax.plot([0.05, 0.95], [y2 - 0.01, y2 - 0.01], color='#2563eb', lw=1.5)

    qa_p1 = [
        ("Q1. What is the entry point and how does the server run?",
         "HttpServerApp.java contains main(). It initializes the ML detector, binds Java's native HttpServer on port 8080 with a thread pool of 10 workers (Executors.newFixedThreadPool(10)), and registers REST endpoints."),
        
        ("Q2. What machine learning model is implemented?",
         "A Hybrid Ensemble combining Multinomial Naive Bayes (55% weight) with an empirical rule-based stylometric classifier (45% weight) inspired by Cornell NLP deception research."),
        
        ("Q3. Why do you use Laplace Add-1 Smoothing in Naive Bayes?",
         "To solve the Zero-Probability Problem. If a test review contains a word never seen in training data for a class, without smoothing P(word|class)=0 would multiply and zero out the entire posterior probability."),
        
        ("Q4. Why do you use log-probabilities instead of multiplying probabilities directly?",
         "To prevent floating-point arithmetic underflow. Multiplying dozens of small fractions (0.0002 x 0.0015...) rounds to zero in computer memory. Logs convert multiplication into stable addition: log(A*B) = log(A) + log(B)."),
        
        ("Q5. What are the decision thresholds for classification?",
         "Fake Probability >= 62% -> FAKE | <= 38% -> GENUINE | Between 38% and 62% -> SUSPICIOUS (uncertain boundary). Confidence is scaled accordingly."),
        
        ("Q6. Why did you deliberately NOT remove pronouns (I, me, my, we) in StopWordFilter?",
         "In deception psychology, deceptive reviewers who lack actual product experience use significantly higher 1st-person pronouns ('I', 'me') to fake personal involvement, making pronouns vital signals rather than noise.")
    ]

    qy = y2 - 0.03
    for q, a in qa_p1:
        ax.add_patch(patches.Rectangle((0.05, qy - 0.045), 0.90, 0.052, facecolor='#f8fafc', edgecolor='#e2e8f0', lw=0.8))
        ax.text(0.065, qy - 0.007, q, fontsize=8.5, fontweight='bold', color='#1e3a8a')
        
        wrapped_a = textwrap.fill(a, width=115)
        ax.text(0.065, qy - 0.023, "Ans: " + wrapped_a, fontsize=7.5, color='#1e293b', va='top')
        qy -= 0.060

    # Footer
    ax.text(0.5, 0.02, "Page 1 of 3 — VeritasAI Viva Defense Cheat Sheet", color='#94a3b8', fontsize=8, ha='center')
    pdf.savefig(fig)
    plt.close(fig)

    # ------------------ PAGE 2 ------------------
    fig2 = plt.figure(figsize=(8.27, 11.69), dpi=100)
    ax2 = fig2.add_axes([0, 0, 1, 1])
    ax2.axis('off')

    # Header Bar
    ax2.add_patch(patches.Rectangle((0.05, 0.92), 0.90, 0.045, facecolor='#1e3a8a', edgecolor='none'))
    ax2.text(0.07, 0.942, "VeritasAI — RAPID-FIRE VIVA QUESTIONS (PART 2)", color='white', fontsize=12, fontweight='bold', va='center')
    ax2.text(0.93, 0.942, "Technical & Algorithmic Answers", color='#93c5fd', fontsize=8.5, ha='right', va='center')

    qa_p2 = [
        ("Q7. What is Automated Readability Index (ARI) in FeatureExtractor?",
         "Formula: ARI = 4.71*(chars/words) + 0.5*(words/sentences) - 21.43. It measures text reading grade level. Fake reviews typically exhibit noticeably lower ARI and repetitive vocabulary compared to authentic user critiques."),
        
        ("Q8. How does the Explainable AI (Word Highlighting) work?",
         "WordHighlight.java tags tokens. Deceptive markers (all-caps shouting, hyperbole phrases like 'miracle', 'buy now') are tagged DECEPTIVE (rendered red in UI). Verified technical attributes ('battery', 'screen', 'fabric') are tagged GENUINE (green)."),
        
        ("Q9. How did you implement JSON parsing without Jackson or Gson?",
         "We built JsonUtil.java from scratch using recursive-descent tokenization. It recursively identifies syntax tokens ({, }, [, ], \", :, commas) and parses nested Maps, Lists, Strings, Numbers, and Booleans with zero external libraries."),
        
        ("Q10. How does the server handle concurrency and multiple simultaneous users?",
         "In HttpServerApp, server.setExecutor(Executors.newFixedThreadPool(10)) dispatches every incoming HTTP request to an idle background worker thread from a 10-thread pool. Synchronized blocks protect shared file repositories."),
        
        ("Q11. Where is data stored? Does it survive a server restart?",
         "Yes. All data persists to disk in the data/ folder as users.json, audit_logs.json, and review_history.json. Repositories read and write safely using synchronized file I/O."),
        
        ("Q12. What is the Owner / Admin Console and how is it secured?",
         "Secured via Role-Based Access Control (RBAC). Only users with role='ADMIN' (admin/admin123) can access /api/admin/* endpoints to inspect real-time user login IPs, review inputs, timestamps, and export audit trails to JSON."),
        
        ("Q13. How does the system evaluate model accuracy and benchmark metrics?",
         "During startup in HybridEnsembleDetector.trainAndEvaluate(), it runs an 80/20 train/test split. It evaluates True Positives (TP), False Positives (FP), True Negatives (TN), and False Negatives (FN) to compute Accuracy, Precision, Recall, and F1-score (~91.8%)."),
        
        ("Q14. What happens when a user submits a review for dynamic retraining?",
         "DatasetHandler receives the review, adds it to DatasetRepository, and triggers retrainWithNewSample(). The Naive Bayes model recalculates class priors, vocabulary frequencies, and benchmark metrics on-the-fly without restarting the server."),
        
        ("Q15. Why is this project better than a simple Python or script-based detector?",
         "It demonstrates complete full-stack enterprise architecture in Java: strict OOP decoupling, multithreaded networking, explainable AI, zero-dependency JSON parsing, and real-time surveillance logging.")
    ]

    qy2 = 0.895
    for q, a in qa_p2:
        ax2.add_patch(patches.Rectangle((0.05, qy2 - 0.053), 0.90, 0.060, facecolor='#f8fafc', edgecolor='#e2e8f0', lw=0.8))
        ax2.text(0.065, qy2 - 0.008, q, fontsize=8.2, fontweight='bold', color='#1e3a8a')
        
        wrapped_a = textwrap.fill(a, width=115)
        ax2.text(0.065, qy2 - 0.024, "Ans: " + wrapped_a, fontsize=7.3, color='#1e293b', va='top')
        qy2 -= 0.067

    # Footer
    ax2.text(0.5, 0.02, "Page 2 of 3 — VeritasAI Viva Defense Cheat Sheet", color='#94a3b8', fontsize=8, ha='center')
    pdf.savefig(fig2)
    plt.close(fig2)

    # ------------------ PAGE 3 ------------------
    fig3 = plt.figure(figsize=(8.27, 11.69), dpi=100)
    ax3 = fig3.add_axes([0, 0, 1, 1])
    ax3.axis('off')

    # Header Bar
    ax3.add_patch(patches.Rectangle((0.05, 0.92), 0.90, 0.045, facecolor='#1e3a8a', edgecolor='none'))
    ax3.text(0.07, 0.942, "VeritasAI — OOP ARCHITECTURE & FORMULAS CHEAT SHEET", color='white', fontsize=12, fontweight='bold', va='center')
    ax3.text(0.93, 0.942, "Object-Oriented Concepts in Action", color='#93c5fd', fontsize=8.5, ha='right', va='center')

    # Section 3: OOP Concepts Table
    y3 = 0.885
    ax3.text(0.05, y3, "3. HOW OBJECT-ORIENTED PRINCIPLES ARE USED (VIVA GOLDMINE)", color='#0f172a', fontsize=11, fontweight='bold', va='center')
    ax3.plot([0.05, 0.95], [y3 - 0.01, y3 - 0.01], color='#2563eb', lw=1.5)

    oops_data = [
        ("Encapsulation", "Review.java, LinguisticFeatures.java",
         "All internal states are private. Access is mediated via validated public getters and strict constructor checks (e.g. throwing IllegalArgumentException if text is empty)."),
        
        ("Polymorphism / Interfaces", "Classifier.java -> MultinomialNaiveBayesClassifier",
         "Classifier defines an interface contract (train, predictFakeProbability). The detector interacts with the interface, allowing new ML models to plug in effortlessly (Open/Closed Principle)."),
        
        ("Facade Design Pattern", "ReviewAnalysisService.java",
         "Provides a unified, simple API (analyze, analyzeBatch) masking the complexity of Tokenizer, FeatureExtractor, Classifiers, Repositories, and Audit loggers."),
        
        ("Repository Design Pattern", "UserRepository, ReviewHistoryRepository",
         "Decouples data access and JSON disk persistence away from business and machine learning logic."),
        
        ("Data Transfer Object (DTO)", "AnalysisResult.java, WordHighlight.java",
         "Carries complex bundled result data (verdicts, probabilities, highlights, execution timings) between architectural tiers and JSON network transport.")
    ]

    ty3 = y3 - 0.035
    for concept, where, desc in oops_data:
        ax3.add_patch(patches.Rectangle((0.05, ty3 - 0.045), 0.25, 0.052, facecolor='#eff6ff', edgecolor='#bfdbfe', lw=0.6))
        ax3.add_patch(patches.Rectangle((0.30, ty3 - 0.045), 0.65, 0.052, facecolor='#ffffff', edgecolor='#cbd5e1', lw=0.6))
        ax3.text(0.06, ty3 - 0.012, concept, fontsize=8.5, fontweight='bold', color='#1d4ed8')
        ax3.text(0.06, ty3 - 0.032, where, fontsize=7, color='#64748b', style='italic')
        wrapped_d = textwrap.fill(desc, width=82)
        ax3.text(0.31, ty3 - 0.012, wrapped_d, fontsize=7.5, color='#334155', va='top')
        ty3 -= 0.058

    # Section 4: Key Formulas Box
    y4 = ty3 - 0.015
    ax3.text(0.05, y4, "4. KEY MATHEMATICAL FORMULAS (MUST-KNOW FOR EXAMINER)", color='#0f172a', fontsize=11, fontweight='bold', va='center')
    ax3.plot([0.05, 0.95], [y4 - 0.01, y4 - 0.01], color='#2563eb', lw=1.5)

    formulas = [
        ("1. Laplace Add-1 Smoothed Word Probability:",
         "P(word | Class) = [ Count(word in Class) + 1 ] / [ TotalWordsInClass + |Vocabulary| ]\n"
         "Guarantees no word probability ever equals zero, preserving numeric continuity in Bayes' Theorem."),
        
        ("2. Hybrid Ensemble Weighted Combination:",
         "FinalFakeProbability = (0.55 * BayesProbability) + (0.45 * RuleDeceptiveWeight)\n"
         "Gives 55% weight to statistical word distribution and 45% to psychological & stylometric cues."),
        
        ("3. Precision, Recall, and F1-Score Metrics:",
         "Accuracy  = (TP + TN) / (TP + FP + TN + FN)\n"
         "Precision = TP / (TP + FP)  |  Recall = TP / (TP + FN)\n"
         "F1-Score  = 2 * (Precision * Recall) / (Precision + Recall)  (Harmonic mean, ~91.8% on benchmark)"),
        
        ("4. Automated Readability Index (ARI):",
         "ARI = 4.71 * (Characters / Words) + 0.5 * (Words / Sentences) - 21.43\n"
         "Quantifies grade level; bot and outsourced spam reviews score significantly lower.")
    ]

    fy = y4 - 0.035
    for title, formula_text in formulas:
        ax3.add_patch(patches.Rectangle((0.05, fy - 0.040), 0.90, 0.048, facecolor='#f8fafc', edgecolor='#cbd5e1', lw=0.8))
        ax3.text(0.065, fy - 0.008, title, fontsize=8, fontweight='bold', color='#1e3a8a')
        ax3.text(0.065, fy - 0.024, formula_text, fontsize=7.2, color='#0f172a', fontfamily='monospace', va='top')
        fy -= 0.054

    # Footer
    ax3.text(0.5, 0.02, "Page 3 of 3 — VeritasAI Viva Defense Cheat Sheet", color='#94a3b8', fontsize=8, ha='center')
    pdf.savefig(fig3)
    plt.close(fig3)

print("SUCCESS: PDF generated at", pdf_path)
